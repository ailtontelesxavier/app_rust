import subprocess
import sys
import os
from pathlib import Path

APPS_DIR = Path(__file__).parent / "app" / "apps"

def run_alembic(app: str, cmd: list[str]):
    ini_path = APPS_DIR / app / "migrations" / "alembic.ini"
    if not ini_path.exists():
        print(f"[!] Alembic config não encontrado para o app '{app}'")
        return

    full_cmd = ["alembic", "-c", str(ini_path)] + cmd
    subprocess.run(full_cmd)

def get_apps():
    return [p.name for p in APPS_DIR.iterdir() if (p / "migrations").exists()]

def main():
    if len(sys.argv) < 3:
        print("Uso: python migrate.py <app|all> <alembic args...>")
        print("Ex:  python migrate.py users upgrade head")
        print("     python migrate.py all revision --autogenerate -m 'init'")
        sys.exit(1)

    app = sys.argv[1]
    cmd = sys.argv[2:]

    if app == "all":
        for a in get_apps():
            print(f"\n==> Executando para o app: {a}")
            run_alembic(a, cmd)
    else:
        run_alembic(app, cmd)

if __name__ == "__main__":
    main()
