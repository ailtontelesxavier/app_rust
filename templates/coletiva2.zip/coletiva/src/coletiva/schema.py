from datetime import datetime
from http import HTTPStatus
from typing import Optional

from fastapi import Form, HTTPException
from pydantic import BaseModel, EmailStr, field_validator
from validate_docbr import CNPJ, CPF

from util import get_numbers


class EscritorioInSchema(BaseModel):
    cnpj: str
    razao_social: str
    nome_fantasia: str
    email: EmailStr

    @field_validator('cnpj')
    def validar_cnpj(cls, v, values):
        if CNPJ().validate(v):
            return get_numbers(v)
        # raise ValueError("CNPJ inválido")
        raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {'CNPJ inválido'}"
            )


class EscritorioOutSchema(EscritorioInSchema):
    id: int


class EscritorioList(BaseModel):
    rows: list[EscritorioOutSchema]
    total_records: int
    current_page: int
    page_size: int
    total_pages: int


class UsuarioInSchema(BaseModel):
    user_id: int
    escritorio_id: int
    is_active: bool


class UsuarioOutSchema(UsuarioInSchema):
    id: int


class UsuarioList(BaseModel):
    rows: list[UsuarioOutSchema]
    total_records: int
    current_page: int
    page_size: int
    total_pages: int


class SindicatoForm(BaseModel):
    cnpj: str
    sigla: str
    razao_social: str
    email: str
    telefone: str
    celular: str
    escritorio_id: int

    @classmethod
    def as_form(
        cls,
        cnpj: str = Form(...),
        sigla: str = Form(...),
        razao_social: str = Form(...),
        email: str = Form(...),
        telefone: str = Form(...),
        celular: str = Form(...),
        escritorio_id: int = Form(...)
    ) -> "SindicatoForm":
        return cls(
            cnpj=cnpj,
            sigla=sigla,
            razao_social=razao_social,
            email=email,
            telefone=telefone,
            celular=celular,
            escritorio_id=escritorio_id
        )


class SindicatoInSchema(BaseModel):
    escritorio_id: int
    cnpj: str
    sigla: str
    razao_social: str
    logotipo: Optional[str] | None = ''
    email: EmailStr
    telefone: str
    celular: str

    @field_validator('cnpj')
    def validar_cnpj(cls, v, values):
        if CNPJ().validate(v):
            return get_numbers(v)
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT,
            detail=f"Conflito de integridade: {'CNPJ inválido'}"
        )


class SindicatoOutSchema(SindicatoInSchema):
    id: int


class SindicatoList(BaseModel):
    rows: list[SindicatoOutSchema]
    total_records: int
    current_page: int
    page_size: int
    total_pages: int
