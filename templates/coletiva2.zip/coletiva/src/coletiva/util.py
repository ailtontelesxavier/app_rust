import os
import shutil
from pathlib import Path
from uuid import uuid4

from fastapi import HTTPException, UploadFile

UPLOAD_DIR = "src/uploads/logotipos"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Tipos MIME permitidos
ALLOWED_MIME_TYPES = {"image/jpeg", "image/png", "application/pdf"}
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".pdf"}


def save_logotipo_file(upload: UploadFile) -> str:
    """
    Salva o arquivo no disco e retorna o caminho relativo.
    """

    if upload.content_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Tipo de arquivo não permitido. Apenas imagens (JPEG, PNG) e PDFs são aceitos.",
        )

    # Verificar a extensão do arquivo
    file_extension = Path(upload.filename).suffix.lower()
    if file_extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Extensão de arquivo não permitida. Apenas arquivos com as extensões {', '.join(ALLOWED_EXTENSIONS)} são aceitos.",
        )

    # Cria um nome único para evitar conflitos
    # Gerar um nome de arquivo único
    while True:
        filename = f"{uuid4().hex}_{upload.filename}"
        file_path = os.path.join(UPLOAD_DIR, filename)
        if not Path(file_path).exists():  # Se não existir, sai do loop
            break

    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(upload.file, buffer)

    # ou apenas filename se for armazenar no banco
    return filename


def delete_file_if_exists(filename: str):
    file_path = os.path.join(UPLOAD_DIR, filename)
    if filename and os.path.exists(file_path):
        os.remove(file_path)
