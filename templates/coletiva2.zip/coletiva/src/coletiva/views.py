import asyncio
import io
from http import HTTPStatus
from typing import Optional

import pandas as pd
from fastapi import (
    APIRouter,
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    Request,
    UploadFile,
    status,
)
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from markupsafe import Markup
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from core.base import T_ParamsBase, T_ParamsPaginacao
from core.repositories import UserRepository
from core.schema import UserInSchema, UserUpdate
from src.coletiva.models import Escritorio
from src.coletiva.repository import (
    EscritorioRepository,
    SindicatoRepository,
    UsuarioRepository,
)
from src.coletiva.schema import (
    EscritorioInSchema,
    EscritorioOutSchema,
    SindicatoForm,
    SindicatoInSchema,
    SindicatoOutSchema,
    UsuarioInSchema,
    UsuarioOutSchema,
)
from util import get_column_names

from . import router

templates = Jinja2Templates(directory="src/templates")


from .views_api import *


limiter = Limiter(key_func=get_remote_address)
router.state.limiter = limiter
router.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


@router.get("/escritorio", response_class=HTMLResponse, name="escritorio-list")
@limiter.limit("5/minute")  # no máximo 5 requisições por IP por minuto
async def get_escritorio(
    base: T_ParamsBase,
    request: Request,
    pag: T_ParamsPaginacao,
):
    """Renderiza a lista de escritórios."""
    # client_ip = get_remote_address(request)

    rep = EscritorioRepository(base.session, base.user)

    result = await rep.get_paginated(
        find=pag.find,
        page=pag.page,
        page_size=pag.page_size,
        search_fields=["nome"]
    )

    # column_names = get_column_names(Escritorio)
    column_names = ["id", "cnpj", "razao_social"]

    headers = ["ID", "Cnpj", "Razão Social", "Ações"]

    return templates.TemplateResponse(
        "coletiva/escritorio.html",
        {
            "request": base.request,
            "column_names": column_names,
            "headers": headers,
            **result
        }
    )


@router.get(
    "/escritorio/",
    response_class=HTMLResponse,
    name="escritorio-form"
)
async def get_escritorio_form(base: T_ParamsBase):
    """Renderiza o formulário de escritório."""
    return templates.TemplateResponse(
        "coletiva/escritorio_form.html",
        {
            "request": base.request,
        },
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
    )


@router.get("/escritorio/{id}", response_class=HTMLResponse)
async def get_escritorio_id(
    base: T_ParamsBase,
    id: int
):
    """Renderiza o escritório específico."""
    rep = EscritorioRepository(base.session, base.user)

    result = await rep.get(id)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail="Escritorio não encontrado"
        )

    return templates.TemplateResponse(
        "coletiva/escritorio_form.html",
        {
            "request": base.request,
            "row": result,
        },
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
    )


@router.post(
    "/escritorio/",
    status_code=status.HTTP_201_CREATED,
    response_model=EscritorioOutSchema
)
async def post_escritorio(
    base: T_ParamsBase,
    escritorio: EscritorioInSchema
):
    """Cria um novo escritório."""
    rep = EscritorioRepository(base.session, base.user)

    result = await rep.create(escritorio)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail="Erro ao criar escritório"
        )

    return result


@router.put(
    "/escritorio/{id}",
    status_code=status.HTTP_200_OK,
    response_model=EscritorioOutSchema
)
async def put_escritorio(
    base: T_ParamsBase,
    id: int,
    escritorio: EscritorioOutSchema
):
    """Atualiza um escritório existente."""
    rep = EscritorioRepository(base.session, base.user)

    if id != escritorio.id:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail="ID do escritório não corresponde ao ID fornecido"
        )

    result = await rep.update(escritorio)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail="Escritorio não encontrado"
        )

    return result


@router.delete(
    "/escritorio/{escritorio_id}",
    status_code=status.HTTP_204_NO_CONTENT
)
async def delete_escritorio(
    base: T_ParamsBase,
    escritorio_id: int,
):
    rep = EscritorioRepository(base.session, base.user)

    return await rep.delete(escritorio_id)


# ################################################################
# ========================= Sindicatos ========================= #
# ################################################################

@router.get("/sindicato", response_class=HTMLResponse, name="sindicato-list")
async def get_sindicato(
    base: T_ParamsBase,
    pag: T_ParamsPaginacao,
):
    """Renderiza a lista de escritórios."""

    rep = SindicatoRepository(base.session, base.user)

    result = await rep.get_paginated(
        find=pag.find,
        page=pag.page,
        page_size=pag.page_size,
        search_fields=["nome"]
    )

    # column_names = get_column_names(Sindicato)
    column_names = ["id", "cnpj", "razao_social"]

    headers = ["ID", "Cnpj", "Razão Social", "Ações"]

    return templates.TemplateResponse(
        "coletiva/sindicato.html",
        {
            "request": base.request,
            "column_names": column_names,
            "headers": headers,
            **result
        }
    )


@router.get(
    "/sindicato/",
    response_class=HTMLResponse,
    name="sindicato-form"
)
async def get_Sindicato_form(base: T_ParamsBase):
    """Renderiza o formulário de escritório."""
    return templates.TemplateResponse(
        "coletiva/sindicato_form.html",
        {
            "request": base.request,
        },
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
    )


@router.get("/sindicato/{id}", response_class=HTMLResponse)
async def get_sindicato_id(
    base: T_ParamsBase,
    id: int
):
    """Renderiza o escritório específico."""
    rep = SindicatoRepository(base.session, base.user)

    result = await rep.get(id)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail="Sindicato não encontrado"
        )

    return templates.TemplateResponse(
        "coletiva/sindicato_form.html",
        {
            "request": base.request,
            "row": result,
        },
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
    )


@router.post(
    "/sindicato/",
    status_code=status.HTTP_201_CREATED,
    response_model=SindicatoOutSchema
)
async def post_sindicato(
    base: T_ParamsBase,
    sindicato_data: SindicatoForm = Depends(SindicatoForm.as_form),
    logotipo: Optional[UploadFile] = File(None)
):
    """Cria um novo escritório."""
    rep = SindicatoRepository(base.session, base.user)

    result = await rep.create(sindicato_data, logotipo)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail="Erro ao criar escritório"
        )

    return result


@router.put(
    "/sindicato/{id}",
    status_code=status.HTTP_200_OK,
    response_model=SindicatoOutSchema
)
async def put_sindicato(
    base: T_ParamsBase,
    id: int,
    sindicato: SindicatoOutSchema
):
    """Atualiza um escritório existente."""
    rep = SindicatoRepository(base.session, base.user)

    if id != sindicato.id:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail="ID do escritório não corresponde ao ID fornecido"
        )

    result = await rep.update(sindicato)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail="Sindicato não encontrado"
        )

    return result


@router.put(
    "/sindicato/imagem/{sindicato_id}",
    status_code=status.HTTP_200_OK,
    response_model=SindicatoOutSchema
)
async def put_sindicato_imagen(
    base: T_ParamsBase,
    sindicato_id: int,
    logotipo: Optional[UploadFile]
):
    """Atualiza ou adiciona uma imagem no sindicato."""
    rep = SindicatoRepository(base.session, base.user)

    result = await rep.create_or_update_image(sindicato_id, logotipo)

    return result


@router.delete(
    "/sindicato/{Sindicato_id}",
    status_code=status.HTTP_204_NO_CONTENT
)
async def delete_Sindicato(
    base: T_ParamsBase,
    Sindicato_id: int,
):
    rep = SindicatoRepository(base.session, base.user)

    return await rep.delete(Sindicato_id)


# ################################################################
# ============ Usuario (Sindictato, advogados) ================= #
# ################################################################

@router.get("/usuario", response_class=HTMLResponse, name="usuario-list")
async def get_usuario(
    base: T_ParamsBase,
    pag: T_ParamsPaginacao,
):
    """Renderiza a lista de escritórios."""

    rep_user = UserRepository(base.session, base.user)

    rep = UsuarioRepository(base.session, base.user)

    result = await rep_user.get_paginated(
        find=pag.find,
        page=pag.page,
        page_size=pag.page_size,
        search_fields=["username", "full_name"]
    )

    # column_names = get_column_names(Sindicato)
    column_names = [
        "id", "username", "full_name", "is_active", "is_staff", "is_superuser"
    ]

    headers = [
        "ID", "Usuario", "Nome", "Ativo", "Funcionario", "Super", "Ações"
    ]

    return templates.TemplateResponse(
        "coletiva/sindicato.html",
        {
            "request": base.request,
            "column_names": column_names,
            "headers": headers,
            **result
        }
    )


@router.get(
    "/usuario-form/",
    response_class=HTMLResponse,
    name="usuario-form"
)
async def get_usuario_form(base: T_ParamsBase):
    """Renderiza o formulário de escritório."""
    return templates.TemplateResponse(
        "coletiva/usuario_form.html",
        {
            "request": base.request,
            "row": None,
        },
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
    )


@router.get("/usuario-form/{id}", response_class=HTMLResponse)
async def get_usuario_id(
    base: T_ParamsBase,
    id: int
):
    """Renderiza o usuário específico."""
    rep = UsuarioRepository(base.session, base.user)
    rep_user = UserRepository(base.session, base.user)

    row = await rep_user.get(id)

    if not row:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail="Usuário não encontrado"
        )

    qr_code_url = row.get_qr_code_base64()

    usuarios = await rep.get_escritorios(row)

    return templates.TemplateResponse(
        "coletiva/usuario_form.html",
        {
            "request": base.request,
            "row": row,
            'qrcode': qr_code_url,
            'list_escritorios': usuarios.get('rows')
        }
    )


@router.post(
    "/usuario-form/",
    status_code=status.HTTP_201_CREATED,
    response_model=UserUpdate
)
async def post_usuario(
    base: T_ParamsBase,
    form: UserInSchema,
):
    """Cria um novo escritório."""
    rep_user = UserRepository(base.session, base.user)

    result = await rep_user.create(form)

    return result


@router.put(
    "/usuario-form/{id}",
    status_code=status.HTTP_200_OK,
)
async def put_usuario(
    base: T_ParamsBase,
    id: int,
    usuario: UserUpdate
):
    """Atualiza um usuário existente."""
    rep = UsuarioRepository(base.session, base.user)
    rep_user = UserRepository(base.session, base.user)

    result = await rep_user.update_user(usuario)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail="Usuário não encontrado"
        )

    return result


@router.delete(
    "/usuario-form/{usuario_id}",
    status_code=status.HTTP_204_NO_CONTENT
)
async def delete_usuario(
    base: T_ParamsBase,
    usuario_id: int,
):
    rep = UsuarioRepository(base.session, base.user)

    return await rep.delete(usuario_id)


# ################################################################
# ======================= Planilha ============================= #
# ################################################################
@router.get(
    "/planilha/",
    response_class=HTMLResponse,
    name="planilha-form"
)
async def get_planilha_form(base: T_ParamsBase):
    """Renderiza o formulário de escritório."""
    return templates.TemplateResponse(
        "coletiva/planilha.html",
        {
            "request": base.request,
        },
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"}
    )


@router.post(
    "/planilha/",
    status_code=status.HTTP_201_CREATED,
)
async def post_planilha(
    base: T_ParamsBase,
    file: UploadFile = File(...),
):
    """Cria um novo escritório."""
    rep = EscritorioRepository(base.session, base.user)

    contents = await file.read()

    # Lê o arquivo Excel diretamente da memória (sem decodificação)
    df = pd.read_excel(
        io.BytesIO(contents),
        dtype=str,  # Lê todos os dados como texto
        engine="openpyxl",  # Recomendado para .xlsx
    )

    # Itera sobre as linhas do DataFrame
    for _, row in df.iterrows():
        print(row)
        # cpf = row["CPF"]
        #nome = row["NOME"]
#
        #if pd.isna(cpf) or pd.isna(nome):
        #    continue  # Ignorar linhas sem CPF ou Nome
#
        #cpf = cpf.strip()
        #nome = nome.strip()

    result = ''  # await rep.create_planilha(file)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail="Erro ao criar escritório"
        )

    return result

#
#@app.get("/listar")
#async def stream_listar_sancionados(base: T_ParamsPaginacao):
#
#    rep = PessoaRepository(base.db)
#    return await rep.verificar_suspeitos()
