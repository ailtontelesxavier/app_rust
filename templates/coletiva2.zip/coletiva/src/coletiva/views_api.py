from core.base import T_ParamsBase, T_ParamsPaginacao

from . import router
from .repository import EscritorioRepository, UsuarioRepository
from .schema import EscritorioList, UsuarioInSchema, UsuarioOutSchema


@router.get(
    "/escritorio-api/",
    response_model=EscritorioList,
    name="escritorio-api"
)
async def get_escritorio_api(
    base: T_ParamsBase,
    pag: T_ParamsPaginacao,
):
    """
    utilizando no componente escritorio
    verifica se o usuario tem permissão
    para acessar o escritorio
    se não tiver retorna 403
    se tiver retorna 200
    se o usuario for superuser
    retorna todos os escritórios
    se o usuario não for superuser
    retorna apenas os escritórios
    que o usuario tem permissão
    se o usuario não tiver permissão
    retorna 403
    """
    rep = EscritorioRepository(base.session, base.user)

    return await rep.get_paginated(
        pag.find,
        pag.page,
        pag.page_size
    )


# ################################################################
# ============ Usuario (Escritorio ao usuario) ================= #
# ################################################################
@router.post(
    "/usuario-escritorio-api/",
    response_model=UsuarioOutSchema,
    name="usuario-escritorio-api"
)
async def post_escritorio_api(
    base: T_ParamsBase,
    usuario_id: int,
    escritorio_id: int,
):
    rep = UsuarioRepository(base.session, base.user)

    row = await rep.create(
        UsuarioInSchema(
            user_id=usuario_id,
            escritorio_id=escritorio_id,
            is_active=True
        )
    )

    return row


@router.put(
    "/usuario-escritorio-api/{usuario_id}",
    response_model=UsuarioOutSchema,
    name="usuario-escritorio-api"
)
async def put_escritorio_api(
    base: T_ParamsBase,
    usuario_id: int,
):
    """
    utilizando para alterar status do usuario 
    no escritoorio ativo ou inativo
    """
    rep = UsuarioRepository(base.session, base.user)

    row = await rep.alter_status(int(usuario_id))

    return row


@router.delete(
    "/usuario-escritorio-api/{usuario_id}",
)
async def delete_escritorio_api(
    base: T_ParamsBase,
    usuario_id=int,
):
    rep = UsuarioRepository(base.session, base.user)

    await rep.delete(int(usuario_id))

    return {"message": "Item deleted"}
