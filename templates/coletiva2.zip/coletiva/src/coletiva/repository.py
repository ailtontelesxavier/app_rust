from datetime import datetime, timedelta
from http import HTTPStatus
from typing import List, Optional

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import and_, func, select
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session

from core.models import User
from core.repositories import BaseRepository, IExists, UpdateSchemaType
from core.security import check_permissions

from .models import Escritorio, Sindicato, Usuario
from .schema import (
    EscritorioInSchema,
    EscritorioOutSchema,
    SindicatoForm,
    SindicatoInSchema,
    SindicatoOutSchema,
    UsuarioInSchema,
    UsuarioOutSchema,
)
from .util import delete_file_if_exists, save_logotipo_file


class EscritorioRepository(
    BaseRepository[
        Escritorio, Session, EscritorioInSchema, EscritorioOutSchema
    ]
):
    """
    Regra para cadastro de escritório:
    escritorio_view
    escritorio_add
    escritorio_edit
    escritorio_delete
    """
    def __init__(self, session: Session, user: User | None):
        super().__init__(Escritorio, session, user)

    async def get_paginated(
        self,
        find: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
        search_fields: Optional[List[str]] = None
    ):
        """
        REGRA1: se não for superuser, lista apenas os escritórios do usuario.
        """
        # super user
        if self.is_permite():
            return await super().get_paginated(
                find, page, page_size, search_fields
            )

        # REGRA1
        self.filters.append(Usuario.user_id == self.user.id)
        joins = [(Usuario, Usuario.escritorio_id == Escritorio.id)]

        return await super().get_paginated(
            find, page, page_size, search_fields, joins=joins
        )

    async def delete(self, id: int):
        """
        so permiter excluir se for o usuario superuser
        se não utilizado
        """
        # obj = await self.get(id)

        if not self.is_permite():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail='Você não tem permissão para excluir'
            )
        return await super().delete(id)


class SindicatoRepository(
    BaseRepository[
        Sindicato, Session, SindicatoInSchema, SindicatoOutSchema
    ]
):
    def __init__(self, session: Session, user: User | None):
        super().__init__(Sindicato, session, user)

    async def get(self, id: int):
        stmt = select(self.model).where(self.model.id == id)
        return self.session.scalars(stmt).one_or_none()

    async def get_total_records(self):
        total_records = self.session.scalar(
                select(func.count()).select_from(self.model)
            )
        total_records = total_records if total_records else 0

        return total_records

    async def get_all(self):
        stmt = select(self.model)
        return self.session.scalars(stmt).all()

    async def get_by_filters(self, filters: List):
        """
        utilizado para gerar relatorios com base em filtros
        """
        subquery = select(self.model).where(and_(*filters)).subquery()
        total_records = self.session.scalar(
            select(func.count()).select_from(subquery)
        )
        rows = self.session.scalars(
            select(self.model).where(
                and_(*filters)
            ).order_by(self.model.id)
        ).all()

        return {
            "rows": rows,
            "total_records": total_records,
        }

    async def create(
        self,
        sindicato_data: SindicatoForm,
        logotipo: UploadFile = None
    ):

        try:
            obj = self.model(**sindicato_data.model_dump())
            self.session.add(obj)
            self.session.flush()
            self.session.refresh(obj)

            if logotipo:
                try:
                    file_path = save_logotipo_file(logotipo)
                    obj.logotipo = file_path
                    self.session.add(obj)
                except Exception as file_error:
                    raise HTTPException(
                        status_code=HTTPStatus.BAD_REQUEST,
                        detail=f"Erro ao salvar logotipo: {str(file_error)}"
                    )
            self.session.commit()
            self.session.refresh(obj)
            return obj

        except IntegrityError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {str(e.orig)}"
            )
        except SQLAlchemyError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                detail="Erro interno no banco de dados."
            )

    async def create_or_update_image(
        self,
        sindicato_id: int,
        logotipo: UploadFile
    ):

        try:
            obj = await self.get(sindicato_id)

            if obj.logotipo:
                # Deletar o arquivo antigo se necessário
                delete_file_if_exists(obj.logotipo)

            if logotipo:
                try:
                    file_path = save_logotipo_file(logotipo)
                    obj.logotipo = file_path
                    self.session.add(obj)
                except Exception as file_error:
                    raise HTTPException(
                        status_code=HTTPStatus.BAD_REQUEST,
                        detail=f"Erro ao salvar logotipo: {str(file_error)}"
                    )
            self.session.commit()
            self.session.refresh(obj)
            return obj

        except IntegrityError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {str(e.orig)}"
            )
        except SQLAlchemyError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                detail="Erro interno no banco de dados."
            )

    async def delete(self, id: int):
        try:
            obj = await self.get(id)
            if obj:
                self.session.delete(obj)
                self.session.commit()
                try:
                    if obj.logotipo:
                        # Deletar o arquivo antigo se necessário
                        delete_file_if_exists(obj.logotipo)
                except Exception as file_error:
                    pass

            return obj

        except IntegrityError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {str(e.orig)}"
            )
        except SQLAlchemyError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                detail="Erro interno no banco de dados."
            )

    async def update(
        self, obj_in: UpdateSchemaType, logotipo: UploadFile = None
    ):
        db_obj = await self.get(obj_in.id)

        if not db_obj:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Objeto não encontrado"
            )

        # Atualiza os campos normais (exceto o logotipo)
        for key, value in obj_in.model_dump(exclude_unset=True).items():
            if key == "logotipo":
                continue  # será tratado abaixo
            current_value = getattr(db_obj, key)
            if current_value != value:
                setattr(db_obj, key, value)

        # Verifica se foi enviado um novo logotipo
        if logotipo:
            # Deleta o arquivo antigo, se houver
            if db_obj.logotipo:
                delete_file_if_exists(db_obj.logotipo)

            # Salva novo logotipo
            novo_path = save_logotipo_file(logotipo)
            db_obj.logotipo = novo_path

        self.session.commit()
        self.session.refresh(db_obj)
        return db_obj


class UsuarioRepository(
    BaseRepository[
        Usuario, Session, UsuarioInSchema, UsuarioOutSchema
    ]
):
    def __init__(self, session: Session, user: User | None):
        super().__init__(Usuario, session, user)

    async def create(self, obj_in: UsuarioInSchema):
        """
        REGRA:
        """
        return await super().create(obj_in)

    async def delete(self, id: int):
        obj = await super().delete(id)
        return obj

    async def alter_status(self, id: int):
        try:
            obj = await self.get(id)
            obj.is_active = not obj.is_active

            self.session.add(obj)
            self.session.commit()
            self.session.refresh(obj)
            return obj
        except IntegrityError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {str(e.orig)}"
            )
        except SQLAlchemyError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                detail="Erro interno no banco de dados."
            )

    async def get_escritorios(self, obj: Usuario) -> List[Escritorio]:
        filters = []
        filters.append(Usuario.user_id == obj.id)
        result = await self.get_by_filters(filters)
        return result


"""

    async def verificar_suspeitos(self):
        #Verifica se existem pessoas suspeitas no banco.

        # via SSE
        queue = asyncio.Queue()

        async def event_generator():
            #Função geradora para enviar eventos conforme os dados são processados.
            while True:
                data = await queue.get()
                if data is None:
                    break  # Finaliza o stream
                yield f"data: {json.dumps(data)}\n\n"

        async def process():
            #Processa os registros e envia eventos SSE.
            total_records = await self.get_total_records()
            page_size = 100
            self.page = 0
            total_pages = ceil(total_records / page_size) if total_records else 1

            tasks = []

            for current_page in range(1, total_pages + 1):
                tasks.append(self._process_page(current_page, page_size, total_records, queue))
            
            results = None
            try:
                results = await asyncio.gather(*tasks)
                results = [r for r in results if r]  # Filtra resultados vazios
                await queue.put({"message": "Processamento finalizado"})
                await queue.put(None)  # Sinaliza o final do stream
            except Exception:
                pass


        asyncio.create_task(process())  # Executa o processamento em background
        return StreamingResponse(event_generator(), media_type="text/event-stream")
    
    async def _process_page(self, page, page_size, total_records, queue):
        #Processa uma única página de registros.
        results = await self._get_page_results(page, page_size)
        if not results:
            return None

        self.page += 1
        for result in results:
            await queue.put({"message": "Processando..", "data": result.to_dict()})
            await self._process_pessoa(result)
        return results

    async def _process_pessoa(self, pessoa):
        #Verifica se uma pessoa é suspeita através de busca concorrente.
        palavras_filtadas = [palavra for palavra in pessoa.nome.split() if len(palavra) > 2]

        loop = asyncio.get_running_loop()
        tasks = [
            loop.run_in_executor(self.executor, self._buscar_individuos, palavra)
            for palavra in palavras_filtadas
        ]
        results = await asyncio.gather(*tasks)

        individuals = [ind for result in results if result for ind in result]
        if individuals:
            self._salvar_suspeitos({"pessoa": pessoa, "individuals": individuals})
        return None

    def _buscar_individuos(self, palavra):
        # Busca indivíduos no banco (executado dentro de thread).
        return asyncio.run(IndividualRepository(self.session).get_search(
            find=palavra,
            search_fields=['first_name', 'second_name', 'third_name']
        ))

    async def _salvar_suspeitos(self, results):
        # Achatar a lista de listas
        results = [r for sublist in results for r in sublist if r] 
        #Salva os suspeitos encontrados no banco.
        for row in results:
            pessoa = row["pessoa"]
            individuals = row["individuals"]

            pessoa_suspeita = PessoaSuspeita(
                cpf=pessoa.cpf,
                nome=pessoa.nome,
                is_validado=False,
            )
            pessoa_suspeita.individuals.extend(individuals)

            self.session.add(pessoa_suspeita)

        self.session.commit()


"""