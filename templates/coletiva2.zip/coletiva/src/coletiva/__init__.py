from fastapi import APIRouter, FastAPI

router = FastAPI(
    title="App Coletiva",
    description="Area coletiva",
    route_class=APIRouter(prefix="/escritorio", tags=["escritorio"]),
)
