from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import (
    BigInteger,
    DateTime,
    ForeignKey,
    String,
    Text,
    UniqueConstraint,
    event,
    func,
)
from sqlalchemy.orm import (
    Mapped,
    Session,
    mapped_column,
    relationship,
)
from sqlalchemy.orm.attributes import get_history

from core.models import HistoricoMixin, TimestampMixin, table_registry
from util import is_instance_of_any


@table_registry.mapped_as_dataclass
class Escritorio(TimestampMixin):
    """Tabela de Escritório de Advocacia"""
    __tablename__ = 'coletiva_escritorios'

    id: Mapped[int] = mapped_column(BigInteger,
        init=False, primary_key=True, autoincrement=True)
    cnpj: Mapped[str] = mapped_column(String(14), unique=True, nullable=False)
    razao_social: Mapped[str] = mapped_column(String, nullable=False)
    nome_fantasia: Mapped[str]
    email: Mapped[str] = mapped_column(String, nullable=False)

    @classmethod
    def get_historico_class(cls):
        return EscritorioHist


@table_registry.mapped_as_dataclass
class EscritorioHist(HistoricoMixin):
    """Tabela de Histórico de Escritório de Advocacia"""
    __tablename__ = "coletiva_escritorios_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger,
        ForeignKey('coletiva_escritorios.id'), default=0)


@table_registry.mapped_as_dataclass
class Usuario(TimestampMixin):
    """Tabela de Usuário"""
    __tablename__ = 'coletiva_usuarios'
    __table_args__ = (
        UniqueConstraint(
            'user_id',
            'escritorio_id',
            name='unique_usuario_user_escritorio',
        ),
    )

    id: Mapped[int] = mapped_column(BigInteger,
        init=False, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    escritorio_id: Mapped[int] = mapped_column(
        ForeignKey('coletiva_escritorios.id')
    )
    is_active: Mapped[bool] = mapped_column(default=True)

    # Relacionamentos
    escritorio = relationship('Escritorio', backref='Usuario')
    user = relationship("User", backref="Usuario")

    @classmethod
    def get_historico_class(cls):
        return UsuarioHist


@table_registry.mapped_as_dataclass
class UsuarioHist(HistoricoMixin):
    __tablename__ = "coletiva_usuarios_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger,
        ForeignKey('coletiva_usuarios.id'), default=0)


# TABELA DE E-MAILS PARA NOTIFICAÇÃO
@table_registry.mapped_as_dataclass
class EmailNotificacao(TimestampMixin):
    __tablename__ = 'coletiva_emails_notificacao'

    id: Mapped[int] = mapped_column(BigInteger,
        init=False, primary_key=True, autoincrement=True)
    escritorio_id: Mapped[int] = mapped_column( ForeignKey('coletiva_escritorios.id'))
    email: Mapped[str] = mapped_column(String, nullable=False)

    # Relacionamento
    escritorio = relationship('Escritorio', backref='EmailNotificacao')

    @classmethod
    def get_historico_class(cls):
        return EmailNotificacaoHist


@table_registry.mapped_as_dataclass
class EmailNotificacaoHist(HistoricoMixin):
    __tablename__ = "coletiva_emails_notificacao_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger,
        ForeignKey('coletiva_emails_notificacao.id'), default=0)


# TABELA DE CELULARES PARA NOTIFICAÇÃO
@table_registry.mapped_as_dataclass
class CelularNotificacao(TimestampMixin):
    __tablename__ = 'coletiva_celulares_notificacao'

    id: Mapped[int] = mapped_column(BigInteger,
        init=False, primary_key=True, autoincrement=True)
    escritorio_id: Mapped[int] = mapped_column(ForeignKey('coletiva_escritorios.id'))
    celular: Mapped[str] = mapped_column(String, nullable=False)

    # Relacionamento
    escritorio = relationship('Escritorio', backref='CelularNotificacao')

    @classmethod
    def get_historico_class(cls):
        return CelularNotificacaoHist


@table_registry.mapped_as_dataclass
class CelularNotificacaoHist(HistoricoMixin):
    __tablename__ = "coletiva_celulares_notificacao_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger,
        ForeignKey('coletiva_celulares_notificacao.id'), default=0)


# TABELA DE SINDICATO
@table_registry.mapped_as_dataclass
class Sindicato(TimestampMixin):
    __tablename__ = 'coletiva_sindicatos'
    __table_args__ = (
        # Adiciona a constraint de unicidade para cnpj e escritorio_id
        UniqueConstraint(
            'cnpj',
            'escritorio_id',
            name='unique_cnpj_escritorio_coletiva_sindicatos',
        ),
    )

    id: Mapped[int] = mapped_column(
        init=False, primary_key=True, autoincrement=True)
    escritorio_id: Mapped[int] = mapped_column(
        ForeignKey('coletiva_escritorios.id')
    )
    cnpj: Mapped[str] = mapped_column(String(14), unique=True, nullable=False)
    sigla: Mapped[str] = mapped_column(String, nullable=False)
    razao_social: Mapped[str] = mapped_column(String, nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False)
    telefone: Mapped[str] = mapped_column(String)
    celular: Mapped[str] = mapped_column(String)
    logotipo: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True,
        default=None
    )

    # Relacionamento
    escritorio = relationship('Escritorio', backref='Sindicato')
    trabalhadores = relationship('Trabalhador', backref='Sindicato')
    modelos_documentos = relationship('ModeloDocumento', backref='Sindicato')

    @classmethod
    def get_historico_class(cls):
        return SindicatoHist


@table_registry.mapped_as_dataclass
class SindicatoHist(HistoricoMixin):
    """
    remove o historico completo
    """
    __tablename__ = "coletiva_sindicatos_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger,
        ForeignKey('coletiva_sindicatos.id', ondelete="CASCADE"), default=0)


# TABELA DE MODELOS DE DOCUMENTOS
@table_registry.mapped_as_dataclass
class ModeloDocumento(TimestampMixin):
    __tablename__ = 'coletiva_modelos_documentos'

    id: Mapped[int] = mapped_column(BigInteger,
        init=False, primary_key=True, autoincrement=True)
    sindicato_id: Mapped[int] = mapped_column( ForeignKey('coletiva_sindicatos.id'))
    nome: Mapped[str] = mapped_column(String, nullable=False)
    conteudo: Mapped[str] = mapped_column(Text, nullable=False)

    # Relacionamento
    sindicato = relationship('Sindicato', backref='ModeloDocumento')

    @classmethod
    def get_historico_class(cls):
        return ModeloDocumentoHist


@table_registry.mapped_as_dataclass
class ModeloDocumentoHist(HistoricoMixin):
    __tablename__ = "coletiva_modelos_documentos_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger,
        ForeignKey('coletiva_modelos_documentos.id'), default=0)


# TABELA DE TRABALHADOR
@table_registry.mapped_as_dataclass
class Trabalhador(TimestampMixin):
    __tablename__ = 'coletiva_trabalhadores'

    id: Mapped[int] = mapped_column(BigInteger,
        init=False, primary_key=True, autoincrement=True)
    sindicato_id: Mapped[int] = mapped_column(ForeignKey('coletiva_sindicatos.id'))
    celular: Mapped[str] = mapped_column(String)
    cpf: Mapped[str] = mapped_column(String(11), unique=True, nullable=False)
    nome: Mapped[str] = mapped_column(String, nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[int] = mapped_column(nullable=False, default=0)

    # Relacionamento
    sindicato = relationship('Sindicato', backref='Trabalhador')

    def get_status(self) -> str:
        keys, values = zip(*Trabalhador.get_list_type())
        return values[keys.index(self.status)]

    @staticmethod
    def get_list_type() -> list:
        return [
            (0, 'Desfiliado'),
            (1, 'Filiado'),
        ]

    @classmethod
    def get_historico_class(cls):
        return TrabalhadorHist


@table_registry.mapped_as_dataclass
class TrabalhadorHist(HistoricoMixin):
    __tablename__ = "coletiva_trabalhadores_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger,
        ForeignKey('coletiva_trabalhadores.id'), default=0)


# TABELA PARA REGISTRAR E-MAILS ENVIADOS
@table_registry.mapped_as_dataclass
class EmailEnviado(TimestampMixin):
    __tablename__ = 'coletiva_emails_enviados'

    id: Mapped[int] = mapped_column(BigInteger,
        init=False, primary_key=True, autoincrement=True)
    trabalhador_id: Mapped[int] = mapped_column(ForeignKey('coletiva_trabalhadores.id'))
    status: Mapped[str] = mapped_column(String, nullable=False)
    titulo: Mapped[str] = mapped_column(String, nullable=False)
    conteudo: Mapped[str] = mapped_column(Text, nullable=False)
    # E-mail, SMS, WhatsApp
    tipo: Mapped[str] = mapped_column(String, nullable=False)
    data_envio: Mapped[datetime] = mapped_column(
        default=func.now()
    )

    # Relacionamento
    trabalhador = relationship('Trabalhador', backref='EmailEnviado')

    def get_tipo(self) -> str:
        keys, values = zip(*Trabalhador.get_list_type())
        return values[keys.index(self.status)]

    @staticmethod
    def get_list_type() -> list:
        return [
            (0, 'e-mail'),
            (1, 'sms'),
            (2, 'whatsapp'),
        ]

    @classmethod
    def get_historico_class(cls):
        return EmailEnviadoHist


@table_registry.mapped_as_dataclass
class EmailEnviadoHist(HistoricoMixin):
    __tablename__ = "coletiva_emails_enviados_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger,
        ForeignKey('coletiva_emails_enviados.id'), default=0)


# ######## historico ##################
@event.listens_for(Session, "after_flush")
def log_solicitacao_updates(session, flush_context):
    for instance in session.dirty:
        if is_instance_of_any(
            instance,
            [
                Escritorio,
                Usuario,
                EmailNotificacao,
                CelularNotificacao,
                Sindicato,
                ModeloDocumento,
                Trabalhador,
                EmailEnviado,
            ]
        ):
            mapper: Mapped = instance.__mapper__
            changes = {}

            for attr in mapper.column_attrs:
                attr_name = attr.key
                history = get_history(instance, attr_name)
                if history.has_changes() and not attr_name in ('created_at', 'updated_at'):
                    changes[attr_name] = {
                        "old": history.deleted[0] if history.deleted else None,
                        "new": history.added[0] if history.added else None,
                    }

            if changes:
                # Pegue o usuário atual do contexto (exemplo)
                usuario = session.info.get("current_user_id", 0)
                historico_class = instance.get_historico_class()
                historico = historico_class(
                    tabela_id=instance.id,
                    usuario_id=usuario,
                    campos_alterados=changes,
                )
                session.add(historico)
