import logging


# Configuração do logging
# Define o nível de log (pode ser INFO, DEBUG, etc.)
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)