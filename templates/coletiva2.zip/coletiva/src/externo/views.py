from typing import Annotated

from fastapi import Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from sqlalchemy.orm import Session

from core.base import T_Base
from core.database import get_session
from externo import router, templates
from externo.views_api import (
    get_portal_data,
    get_portal_router,
    processo_consulta,
)

limiter = Limiter(key_func=get_remote_address)
router.state.limiter = limiter
router.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


@router.get("/", response_class=HTMLResponse, name="externo-index")
@limiter.limit("20/minute")  # Limita a 10 requisições por minuto
async def get_index(
    base: T_Base,
    request: Request,
):
    # client_ip = get_remote_address(request)
    portal_data = await get_portal_data(base.cnpj)

    return templates.TemplateResponse(
        "index.html",
        {
            "request": base.request,
            "portal_data": portal_data,
            "base_url": base.base_url,
        }
    )


@router.get("/sobre", response_class=HTMLResponse, name="sobre")
@limiter.limit("20/minute")
async def about_page(
    base: T_Base,
    request: Request,
):
    portal_data = await get_portal_data(base.cnpj)

    return templates.TemplateResponse(
        "about-page.html",
        {
            "request": base.request,
            "portal_data": portal_data,
            "base_url": base.base_url,
        }
    )


@router.get(
    "/validar-documento",
    response_class=HTMLResponse,
    name="validar-documento"
)
@limiter.limit("20/minute")
async def validar_documento(
    base: T_Base,
    request: Request,
):

    portal_data = await get_portal_data(base.cnpj)

    return templates.TemplateResponse(
        "validar-documento.html",
        {
            "request": base.request,
            "cnpj": base.cnpj,
            "portal_data": portal_data,
            "base_url": base.base_url,
        }
    )


@router.get(
    "/contato",
    response_class=HTMLResponse,
    name="contato"
)
@limiter.limit("20/minute")
async def contact_page(
    base: T_Base,
    request: Request,
):
    portal_data = await get_portal_data(base.cnpj)

    return templates.TemplateResponse(
        "contact-page.html",
        {
            "request": base.request,
            "portal_data": portal_data,
            "base_url": base.base_url,
        }
    )
