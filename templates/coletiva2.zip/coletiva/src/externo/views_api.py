from http import HTTPStatus
from typing import Annotated

import httpx
from fastapi import Depends, Form, HTTPException, Request
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from core.base import T_Base
from core.settings import get_settings
from externo.schema import (
    ProcessoAssinarDocumentoSchema,
    ProcessoConsultaSchema,
    ProcessoGeraTokenSchema,
    ProcessoReenviarTokenSchema,
    ProcessoValidarDocumentoSchema,
)
from util import get_numbers

from . import router

settings = get_settings()

DJANGO_API_URL = settings.DJANGO_API_URL or "https://api.portalacaocoletiva.com.br/api/"
CLIENT_ID = settings.CLIENT_ID or "27282298000126"
CLIENT_SECRET = "pbkdf2_sha256$260000$Q8pVTU54lK1YQGJFFOVtZP$NHjLdCSKsApgObWFm5dUMAorQ0tF2aq9CKmnMxdpzWQ="
HEADER_NAME = "header"

headers = {
    HEADER_NAME: CLIENT_SECRET
}

RECAPTCHA_SECRET_KEY = "6LecKbMUAAAAAE6cYA5F71F6vHGycon5MCRtG7OT"
RECAPTCHA_VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify"


limiter = Limiter(key_func=get_remote_address)
router.state.limiter = limiter
router.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


async def get_portal_data(cnpj: str):
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
            response = await client.get(
                DJANGO_API_URL + "portal-home",
                headers=headers,
                params={"cnpj": cnpj}
            )

        if response.status_code == 200:
            return response.json()

        raise HTTPException(
            status_code=response.status_code,
            detail=response.text + ' .Por favor, tente novamente.'
        )

    except Exception as e:
        print(f"Erro ao buscar portal-home: {e}")
        return {}


def get_portal_router():
    """
    obtem o portal router
    """
    try:
        with httpx.Client(timeout=httpx.Timeout(30.0)) as client:
            response = client.get(
                DJANGO_API_URL + "portal-router",
                headers=headers,
            )

        if response.status_code == 200:
            return response.json()

        raise HTTPException(
            status_code=response.status_code,
            detail=response.text + ' .Por favor, tente novamente.'
        )

    except Exception as e:
        print(f"Erro ao buscar portal-home: {e}")
        return {}


@router.post(
    "/processo-consulta/",
    name="processo-consulta"
)
@limiter.limit("20/minute")
async def processo_consulta(
    base: T_Base,
    request: Request,
    form: ProcessoConsultaSchema,
):
    """
    Consulta processo
    """
    # Verifica o token do reCAPTCHA
#    async with httpx.AsyncClient() as client:
#        response = await client.post(
#            RECAPTCHA_VERIFY_URL,
#            data={
#                'secret': RECAPTCHA_SECRET_KEY,
#                'response': form.recaptcha_token
#            }
#        )
#        result = response.json()
#
#    if result.get("success") and result.get("score", 0) > 0.5:
        # reCAPTCHA válido — continue o processamento
    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.get(
            DJANGO_API_URL + "processo-consulta",
            headers=headers,
            params={
                "cnpj": base.cnpj,
                'cpf': get_numbers(form.cpf),
                'ip': base.client_ip
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text + ' .Por favor, tente novamente.'
        )
#    else:
#        raise HTTPException(
#                status_code=400,
#                detail="Falha na verificação do reCAPTCHA. Por favor, tente novamente."
#            )


@router.post(
    "/processo-gerar-termo/",
    name="processo-gerar-termo"
)
@limiter.limit("20/minute")
async def processo_gerar_termo(
    base: T_Base,
    request: Request,
    form: ProcessoConsultaSchema
):
    """
    Gerar token
    """
    # Verifica o token do reCAPTCHA
    async with httpx.AsyncClient() as client:
        response = await client.post(
            RECAPTCHA_VERIFY_URL,
            data={
                'secret': RECAPTCHA_SECRET_KEY,
                'response': form.recaptcha_token
            }
        )
        result = response.json()

    if result.get("success") and result.get("score", 0) > 0.5:
        async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
            response = await client.post(
                DJANGO_API_URL + "processo-gerar-termo",
                headers=headers,
                params={
                    "cnpj": base.cnpj,
                    'cpf': get_numbers(form.cpf),
                    'ip': base.client_ip
                },
            )

        if response.status_code == 200:
            return response.json()

        else:
            raise HTTPException(
                status_code=response.status_code,
                detail=response.text + ' .Por favor, tente novamente.'
            )
    else:
        raise HTTPException(
                status_code=400,
                detail="Falha na verificação do reCAPTCHA. Por favor, tente novamente."
            )


@router.post(
    "/processo-gerar-token/",
    name="processo-gerar-token"
)
@limiter.limit("20/minute")
async def processo_gerar_token(
    base: T_Base,
    request: Request,
    form: ProcessoGeraTokenSchema
):
    """
    Gerar token
    """

    ambiente_producao = not settings.DEBUG

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.post(
            DJANGO_API_URL + "processo-gerar-token",
            headers=headers,
            params={
                "cnpj": base.cnpj,
                'cpf': get_numbers(form.cpf),
                'email': form.email,
                'celular': form.telefone,
                'ambiente_producao': ambiente_producao,
                'ip': base.client_ip
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT,
            detail=response.text + ' .Por favor, tente novamente.'
        )


@router.post(
    "/processo-assinar-documento/",
    name="processo-assinar-documento"
)
@limiter.limit("20/minute")
async def processo_assinar_documento(
    base: T_Base,
    request: Request,
    form: ProcessoAssinarDocumentoSchema
):
    """
    assinar documento
    """

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.post(
            DJANGO_API_URL + "processo-assinar-documento",
            headers=headers,
            params={
                "cnpj": base.cnpj,
                'cpf': get_numbers(form.cpf),
                'token': form.token,
                'ip': base.client_ip
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text + ' .Por favor, tente novamente.'
        )


@router.post(
    "/processo-validar-documento/",
    name="processo-validar-documento"
)
@limiter.limit("20/minute")
async def processo_validar_documento(
    base: T_Base,
    request: Request,
    form: ProcessoValidarDocumentoSchema
):
    """
    assinar documento
    """

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.get(
            DJANGO_API_URL + "processo-validar-documento",
            headers=headers,
            params={
                "cnpj": base.cnpj,
                'codigo': form.codigo,
                'ip': base.client_ip
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text + ' .Por favor, tente novamente.'
        )


@router.post(
    "/processo-reenviar-token/",
    name="processo-reenviar-token"
)
@limiter.limit("20/minute")
async def processo_reenviar_token(
    base: T_Base,
    request: Request,
    form: ProcessoReenviarTokenSchema
):
    """
    reenviar token
    """

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.post(
            DJANGO_API_URL + "processo-reenviar-token",
            headers=headers,
            params={
                "cnpj": base.cnpj,
                'cpf': get_numbers(form.cpf),
                'ip': base.client_ip
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text + ' .Por favor, tente novamente.'
        )
