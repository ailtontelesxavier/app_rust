from typing import Optional

from pydantic import BaseModel, EmailStr, field_validator
from validate_docbr import CNPJ, CPF


class ProcessoConsultaSchema(BaseModel):
    cpf: str
    recaptcha_token: Optional[str]

    @field_validator('cpf')
    def validate_cpf(cls, v):
        if not CPF().validate(v):
            raise ValueError("CPF inválido")
        return v


class ProcessoAssinarDocumentoSchema(BaseModel):
    cpf: str
    token: str


class ProcessoValidarDocumentoSchema(BaseModel):
    codigo: str
    cnpj: str


class ProcessoReenviarTokenSchema(BaseModel):
    cpf: str

    @field_validator('cpf')
    def validate_cpf(cls, v):
        if not CPF().validate(v):
            raise ValueError("CPF inválido")
        return v


class ProcessoGeraTokenSchema(BaseModel):
    cpf: str
    email: Optional[EmailStr]
    telefone: Optional[str]

    @field_validator('cpf')
    def validate_cpf(cls, v):
        if not CPF().validate(v):
            raise ValueError("CPF inválido")
        return v