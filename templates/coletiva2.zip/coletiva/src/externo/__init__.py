from fastapi import APIRouter, FastAPI
from fastapi.templating import Jinja2Templates

templates = Jinja2Templates(directory="src/templates/externo")

router = FastAPI(
    title="App Coletiva",
    description="Area externa",
    route_class=APIRouter(tags=["externo"]),
)
