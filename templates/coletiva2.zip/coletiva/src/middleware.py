from typing import Annotated, Optional

from fastapi import Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from jwt import DecodeError, decode
from jwt.exceptions import ExpiredSignatureError
from sqlalchemy.orm import Session
from starlette.middleware.base import BaseHTTPMiddleware

from core.database import get_session
from core.security import verify_token
from core.settings import Settings

settings = Settings()
T_Session = Annotated[Session, Depends(get_session)]


# Lista de rotas que não exigem autenticação
public_routes = [
    "/metrics", "/", '/index', '/about-page', '/contato', '/sobre', '/validar-documento',
    '/contact-page', '/processo-consulta/', '/processo-gerar-termo/',
    '/processo-gerar-token/', '/processo-assinar-documento/',
    '/processo-validar-documento/', '/processo-reenviar-token/',
    '/externo/', '/externo/empresa-form',
    "/externo/empresa-form/", "/login", "/docs",
    '/openapi.json', "/auth/token", "/auth/verify-token",
    '/favicon.ico', "/uploads", "/send-email/",
    "/editor"
]


# Middleware para verificação de perfil do usuário
class RoleCheckMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):  # noqa: PLR6301
        # Permitir que as rotas públicas sejam acessadas sem autenticação
        if (
            request.url.path in public_routes
            or request.url.path.startswith("/externo/")
            or request.url.path.startswith("/static/")
        ):
            return await call_next(request)

        # Verifica se há o cabeçalho de autenticação
        auth_header: Optional[str] = request.cookies.get("access_token")
        # auth_header: Optional[str] = request.headers.get("Authorization")

        if not auth_header:
            # Se o cabeçalho não existir e não estiver tentando acessar rotas públicas
            # Deixe passar caso o usuário ainda não esteja autenticado, por exemplo, na tela de login
            # raise HTTPException(status_code=403, detail="Authorization header missing")
            return RedirectResponse(url="/login")

        token = auth_header.split(" ")[0]
        try:
            payload = decode(
                token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
            )
            username: str = payload.get('sub')
            exp: str = payload.get('exp')
            if not username or not exp:
                # raise credentials_exception
                return RedirectResponse(url="/login")
        except DecodeError:
            raise HTTPException(status_code=403, detail="Authorization DecodeError")
        except ExpiredSignatureError:
            return RedirectResponse(url="/login")
            # raise HTTPException(status_code=403, detail="Authorization ExpiredSignatureError")

        if not verify_token(payload):
            # Se o token estiver expirado, redireciona para a página de login
            return RedirectResponse(url="/login")

        # continua o acesso controla no router
        response = await call_next(request)
        return response
