import re
from datetime import datetime
from decimal import Decimal

import pytz
from sqlalchemy import inspect


def get_data_now_for_time_zone():
    TIME_ZONE = 'America/Sao_Paulo'
    tz = pytz.timezone(TIME_ZONE)
    return datetime.now(tz)


def get_numbers(numbers):
    # re.sub('[^a-zA-Z0-9 \n\.]', '', numers)
    # return re.sub('[^0-9]', '', numbers)
    # Remover caracteres não numéricos
    return re.sub(r"\D", "", numbers)


def remover_nao_numericos(texto):
    # \D corresponde a qualquer caractere que
    # não seja um dígito
    return re.sub(r'\D', '', texto)


def to_serializable(val):
    if isinstance(val, Decimal):
        return float(val)
    if isinstance(val, datetime):
        return val.isoformat()
    return val


def is_instance_of(obj, cls):
    '''Verifica se o objeto é uma instância da classe'''
    return isinstance(obj, cls)


def is_instance_of_any(obj, classes):
    '''Verifica se o objeto é uma instância de uma lista de classes'''
    return isinstance(obj, tuple(classes))


def get_column_names(cls):
    """Retorna os nomes das colunas de uma classe SQLAlchemy."""
    return [column.name for column in inspect(cls).c]