import base64
import logging
import re
from datetime import datetime
from io import BytesIO

import pyotp
import pytz
import qrcode
import sqlalchemy as sa
from fastapi.responses import StreamingResponse
from sqlalchemy import (
    BigInteger,
    ForeignKey,
    Identity,
    Integer,
    MetaData,
    String,
    UniqueConstraint,
    event,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy.orm import (
    Mapped,
    Session,
    mapped_column,
    registry,
    relationship,
    validates,
)
from sqlalchemy.orm.attributes import get_history

from util import is_instance_of_any

table_registry = registry()
metadata = MetaData()


# Configuração do logging
# Define o nível de log (pode ser INFO, DEBUG, etc.)
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class TimestampMixin:
    """Mixin para campos de timestamp padrão"""
    created_at: Mapped[datetime] = mapped_column(
        init=False,
        server_default=func.now(),
        default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        init=False,
        server_default=func.now(),
        onupdate=func.now(),
        default=func.now()
    )


class HistoricoMixin:
    """Mixin para tabelas de histórico"""
    # Campos SEM valor padrão primeiro
    tabela_id: Mapped[int] = mapped_column(BigInteger, default=0)
    # Campos COM valor padrão depois
    id: Mapped[int] = mapped_column(
        BigInteger,
        init=False,
        primary_key=True,
        autoincrement=True
    )
    usuario_id: Mapped[int]
    campos_alterados: Mapped[dict] = mapped_column(
        MutableDict.as_mutable(JSONB),
        default_factory=dict
    )
    data_alteracao: Mapped[datetime] = mapped_column(default=func.now())


@table_registry.mapped_as_dataclass
class Module(TimestampMixin):
    __tablename__ = "module"
    id: Mapped[int] = mapped_column(init=False, primary_key=True)
    title: Mapped[str] = mapped_column(
        String(255),
        unique=True,
        nullable=False
    )


@table_registry.mapped_as_dataclass
class Permission(TimestampMixin):
    __tablename__ = 'permission'
    """     __table_args__ = (
            UniqueConstraint('name', 'module_id', name='uix_name_modules'),
        )
    """
    id: Mapped[int] = mapped_column(init=False, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(nullable=True)
    module_id: Mapped[int] = mapped_column(ForeignKey('module.id'))

    module = relationship('Module', backref='Permission')
    # module = relationship('Module', back_populates='permission')

    role_permissions = relationship(
        "RolePermissions",
        back_populates="permission",
        overlaps="roles"
    )

    roles = relationship(
        'Role',
        secondary='role_permissions',
        back_populates='permissions',
        overlaps="role_permissions"
    )

    def __repr__(self):
        return f'<Permission {self.name}>'


@table_registry.mapped_as_dataclass
class Role(TimestampMixin):
    __tablename__ = 'roles'

    id: Mapped[int] = mapped_column(init=False, primary_key=True)
    name: Mapped[str] = mapped_column(unique=True, index=True)

    permissions = relationship(
        'Permission',
        secondary='role_permissions',
        back_populates='roles',
        overlaps="role_permissions",
        order_by='Permission.module_id',
    )

    role_permissions = relationship(
        "RolePermissions",
        back_populates="role",
        overlaps="permissions"
    )

    def __repr__(self):
        return f'<Role {self.name}>'


# Associação muitos-para-muitos entre Roles e Permissões
@table_registry.mapped_as_dataclass
class RolePermissions(TimestampMixin):
    __tablename__ = 'role_permissions'
    __table_args__ = (
        UniqueConstraint(
            'role_id',
            'permission_id',
            name='unique_role_permission'
        ),
    )

    id: Mapped[int] = mapped_column(
        BigInteger,
        init=False,
        primary_key=True,
        autoincrement=True
    )
    role_id: Mapped[int] = mapped_column(
        ForeignKey('roles.id'), primary_key=True)
    permission_id: Mapped[int] = mapped_column(
            ForeignKey('permission.id'), primary_key=True
        )

    role = relationship(
        'Role',
        back_populates="role_permissions",
        overlaps='permissions'
    )
    permission = relationship(
        'Permission',
        back_populates="role_permissions",
        overlaps="roles"
    )


@table_registry.mapped_as_dataclass
class UserRoles(TimestampMixin):
    __tablename__ = 'user_roles'

    id: Mapped[int] = mapped_column(init=False, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    role_id: Mapped[int] = mapped_column(ForeignKey('roles.id'))

    role = relationship('Role', backref='UserRoles', overlaps="roles")
    # user = relationship('User', backref='UserRoles')

    user = relationship(
       'User',
       backref='UserRoles',
       primaryjoin="User.id == UserRoles.user_id",
       overlaps="roles,User"
    )

    # user = relationship(
    #     'User',
    #     back_populates='roles',
    #     overlaps="roles,User"
    # )


@table_registry.mapped_as_dataclass
class User(TimestampMixin):
    __tablename__ = 'users'

    id: Mapped[int] = mapped_column(init=False, primary_key=True)
    username: Mapped[str] = mapped_column(unique=True, index=True)
    password: Mapped[str]
    email: Mapped[str] = mapped_column(unique=True)
    full_name: Mapped[str]
    otp_auth_url: Mapped[str] = mapped_column(nullable=True)
    otp_base32: Mapped[str] = mapped_column(nullable=True)
    is_active: Mapped[bool] = mapped_column(default=True)
    is_staff: Mapped[bool] = mapped_column(default=True)
    is_superuser: Mapped[bool] = mapped_column(default=False)
    last_login: Mapped[datetime] = mapped_column(
        nullable=True,
        default=None
    )

    otp_created_at: Mapped[datetime] = mapped_column(default=func.now())

    # roles = relationship('UserRoles', backref='User', lazy='dynamic')
    roles = relationship(
        'UserRoles',
        back_populates='user',
        overlaps="UserRoles,user"
    )

    def __repr__(self):
        return f'<User {self.username} - {self.email} >'

    def validar_senha(password):
        if len(password) < int(6):
            return False
        password_regex = re.compile(r'^(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*])')
        return bool(password_regex.search(password))

    @validates('username')
    def validate_username(self, key, value):  # noqa: PLR6301
        if value is None or not value:
            raise ValueError('Username não pode ser vazio')
        return value

    @validates('full_name')
    def validate_full_name(self, key, value):  # noqa: PLR6301
        if value is None or not value:
            raise ValueError('full_name não pode ser vazio')
        return value

    @classmethod
    def create_otp_base32(cls):
        return pyotp.random_base32()

    def get_otp_url(self):
        return pyotp.TOTP(self.otp_base32).provisioning_uri(
            name=self.username.lower(), issuer_name=self.username
        )

    def get_qr_code(self):
        stream = BytesIO()
        image = qrcode.make(f'{self.get_otp_url()}')
        image.save(stream, format="PNG")
        self.qr_code = stream.getvalue()
        # return self.qr_code
        stream.seek(0)
        return StreamingResponse(stream, media_type="image/png")

    def get_qr_code_base64(self) -> str:
        stream = BytesIO()
        image = qrcode.make(f'{self.get_otp_url()}')
        image.save(stream, format="PNG")
        stream.seek(0)
        img_base64 = base64.b64encode(stream.getvalue()).decode('utf-8')
        return f"data:image/png;base64,{img_base64}"

    def is_valid_otp(self, otp: str) -> bool:
        """lifespan_in_seconds = 30

        TIME_ZONE = 'America/Sao_Paulo'
        tz = pytz.timezone(TIME_ZONE)

        now = datetime.now(tz)
        time_diff = now - self.otp_created_at.replace(tzinfo=tz)
        time_diff = time_diff.total_seconds()
        if time_diff >= lifespan_in_seconds:
            return False"""

        TIME_ZONE = 'America/Sao_Paulo'
        tz = pytz.timezone(TIME_ZONE)

        totp = pyotp.TOTP(self.otp_base32)
        local_time = datetime.now(tz)
        logger.debug(f"Hora atual no fuso horário {TIME_ZONE}: {local_time}")
        return totp.verify(otp, for_time=local_time)


    def get_otp_auth_url(self):
        self.otp_auth_url = pyotp.TOTP(self.otp_base32).provisioning_uri(
            name=self.full_name.lower(), issuer_name='Codigo'
        )
        return self.otp_auth_url

    @classmethod
    def get_historico_class(cls):
        return UserHist


@table_registry.mapped_as_dataclass
class UserHist(HistoricoMixin):
    __tablename__ = "users_hist"

    tabela_id: Mapped[int] = mapped_column(BigInteger, ForeignKey('users.id'), default=0)


# ######## historico ##################
@event.listens_for(Session, "after_flush")
def log_solicitacao_updates(session, flush_context):
    for instance in session.dirty:
        if is_instance_of_any(
            instance,
            [
                User,
            ]
        ):
            mapper: Mapped = instance.__mapper__
            changes = {}

            for attr in mapper.column_attrs:
                attr_name = attr.key
                history = get_history(instance, attr_name)
                if history.has_changes() and not (attr_name in ('created_at', 'updated_at', 'otp_created_at')):
                    changes[attr_name] = {
                        "old": history.deleted[0] if history.deleted else None,
                        "new": history.added[0] if history.added else None,
                    }

            if changes:
                # Pegue o usuário atual do contexto (exemplo)
                usuario = session.info.get("current_user_id", 0)
                historico_class = instance.get_historico_class()
                historico = historico_class(
                    tabela_id=instance.id,
                    usuario_id=usuario,
                    campos_alterados=changes,
                )
                session.add(historico)
