from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

# ACCESS_TOKEN_EXPIRE_MINUTES =
#  int(os.environ.get("ACCESS_TOKEN_EXPIRE_MINUTES", 30))


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file='.env', env_file_encoding='utf-8', extra='ignore'
    )

    env: str = "development"  # "development" ou "production"
    DEBUG: bool
    DATABASE_URL: str
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int
    NAME: str
    USER: str
    PASSWORD: str
    HOST: str
    PORT: str
    CLIENT_ID: str
    DJANGO_API_URL: str = "https://api.portalacaocoletiva.com.br/api/"


@lru_cache()
def get_settings() -> Settings:
    settings = Settings()

    # Lógica para produção
    if settings.env == "production":
        settings.DEBUG = False
        # Ex: settings.log_level = "warning"
    else:
        settings.DEBUG = True

    # settings.DEBUG = True
    return settings
