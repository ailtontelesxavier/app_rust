from abc import ABC, abstractmethod
from datetime import datetime
from http import HTTPStatus
from math import ceil
from typing import Generic, List, Optional, Tuple, Type, TypeVar

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import (
    BinaryExpression,
    Float,
    Integer,
    Select,
    String,
    and_,
    cast,
    select,
)
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import ColumnProperty, Session, declarative_base
from sqlalchemy.sql.expression import func, or_

from coletiva.util import delete_file_if_exists, save_logotipo_file
from util import get_data_now_for_time_zone

from .models import Module, Role, RolePermissions, User
from .schema import (
    ModuleInSchema,
    ModuleOutSchema,
    PerfilPermissaoInSchema,
    PerfilPermissaoOutSchema,
    RoleInSchema,
    RoleOutSchema,
    UserInSchema,
    UserUpdate,
)
from .security import (
    check_permissions,
    get_password_hash,
    verify_password,
)

Base = declarative_base()

# Tipos genéricos para modelos do SQLAlchemy
T = TypeVar("T", bound=Base)

# Definição dos tipos genéricos
ModelType = TypeVar("ModelType", bound=Base)
SessionType = TypeVar("SessionType", bound=Session)
CreateSchemaType = TypeVar("CreateSchemaType")
UpdateSchemaType = TypeVar("UpdateSchemaType")


class IRepository(
    ABC,
    Generic[ModelType, SessionType, CreateSchemaType, UpdateSchemaType]
):
    @abstractmethod
    async def get(self, id: int) -> Optional[ModelType]:
        ...

    @abstractmethod
    async def get_all(self) -> List[ModelType]:
        ...

    @abstractmethod
    async def get_by_filters(self, filters: List) -> dict:
        ...

    @abstractmethod
    async def create(self, obj_in: CreateSchemaType) -> ModelType:
        ...

    @abstractmethod
    async def update(
        self, db_obj: ModelType, obj_in: UpdateSchemaType) -> ModelType:
        ...

    @abstractmethod
    async def delete(self, id: int) -> Optional[ModelType]:
        ...

    @abstractmethod
    async def get_paginated(
        self,
        find: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
        search_fields: Optional[List[str]] = None
    ) -> dict:
        ...

    @abstractmethod
    async def is_permite(self, permissions: List[str]) -> bool:
        pass


class IExists(ABC):
    @abstractmethod
    async def exists(self, id: int) -> bool:
        """
        Verifica se existe na tabela.
        """
        pass


class BaseRepository(
    IRepository[ModelType, SessionType, CreateSchemaType, UpdateSchemaType]
):
    def __init__(
        self,
        model: Type[ModelType],
        session: SessionType,
        user: User = None
    ):
        self.model = model
        self.session = session
        self.user = user
        self.filters = []

    async def get(self, id: int):
        stmt = select(self.model).where(self.model.id == id)
        return self.session.scalars(stmt).one_or_none()

    async def get_total_records(self):
        total_records = self.session.scalar(
                select(func.count()).select_from(self.model)
            )
        total_records = total_records if total_records else 0

        return total_records

    async def get_all(self):
        stmt = select(self.model)
        return self.session.scalars(stmt).all()

    async def get_by_filters(self, filters: List):
        """
        utilizado para gerar relatorios com base em filtros
        """
        subquery = select(self.model).where(and_(*filters)).subquery()
        total_records = self.session.scalar(
            select(func.count()).select_from(subquery)
        )
        rows = self.session.scalars(
            select(self.model).where(
                and_(*filters)
            ).order_by(self.model.id)
        ).all()

        return {
            "rows": rows,
            "total_records": total_records,
        }

    async def create(self, obj_in: CreateSchemaType):
        try:
            obj = self.model(**obj_in.model_dump(exclude_unset=True))
            self.session.add(obj)
            self.session.commit()
            self.session.refresh(obj)
            return obj
        except IntegrityError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {str(e.orig)}"
            )
        except SQLAlchemyError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                detail="Erro interno no banco de dados."
            )

    async def update(
        self, obj_in: UpdateSchemaType
    ):
        """
        obj_in: dados que serar atualizados
        """
        try:
            db_obj = await self.get(obj_in.id)

            if not db_obj:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Objeto não encontrado"
                )

            for key, value in obj_in.model_dump(exclude_unset=True).items():
                current_value = getattr(db_obj, key)
                if current_value != value:
                    setattr(db_obj, key, value)
            self.session.commit()
            self.session.refresh(db_obj)
            return db_obj
        except IntegrityError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {str(e.orig)}"
            )
        except SQLAlchemyError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                detail="Erro interno no banco de dados."
            )

    async def delete(self, id: int):
        try:
            obj = await self.get(id)
            if obj:
                self.session.delete(obj)
                self.session.commit()
            return obj
        except IntegrityError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {str(e.orig)}"
            )
        except SQLAlchemyError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                detail="Erro interno no banco de dados."
            )

    def is_permite(self, permissions: List[str] = None) -> bool:
        """
        verifica se usuario tem a permissao ou é super user
        """
        if not permissions and not self.user.is_superuser:
            return False
        elif not self.user.is_superuser and not check_permissions(
            current_user=self.user,
            permissions=permissions,
        ):
            return False
        return True

    async def get_paginated(
        self,
        find: Optional[str] = None,
        page: int = 1,
        page_size: int = 10,
        search_fields: Optional[List[str]] = None,
        joins: Optional[List[Tuple[Type, BinaryExpression]]] = None
    ):
        """Método genérico para obter dados paginados com busca opcional."""
        skip = (page - 1) * page_size
        limit = page_size

        # Build base SELECT
        stmt: Select = select(self.model)

        if joins:
            for model_to_join, on_clause in joins:
                stmt = stmt.join(model_to_join, on_clause)

        # WHERE básico
        where_clause = and_(*self.filters) if self.filters else None

        if not find:
            count_stmt = select(func.count()).select_from(self.model)
            if joins:
                for model_to_join, on_clause in joins:
                    count_stmt = count_stmt.join(model_to_join, on_clause)

            if where_clause is not None:
                count_stmt = count_stmt.where(where_clause)

            total_records = self.session.scalar(count_stmt)

            stmt = stmt.where(
                where_clause
            ) if where_clause is not None else stmt

            stmt = stmt.order_by(self.model.id).offset(skip).limit(limit)

            rows = self.session.scalars(stmt).all()
            total_pages = ceil(
                total_records / page_size
            ) if total_records else 1

            return self._format_response(
                rows, total_records, page, page_size, total_pages
            )

        # Busca com LIKE ou CAST ILIKE
        partial_title = f"%{find}%"
        filters = []

        for field in search_fields or []:
            column_attr = getattr(self.model, field)
            column_type = (
                column_attr.property.columns[0].type
                if hasattr(column_attr.property, "columns")
                else None
            )

            if isinstance(column_type, (Integer, Float)):
                filters.append(cast(column_attr, String).ilike(partial_title))
            else:
                filters.append(column_attr.ilike(partial_title))

        combined_where = and_(
            *(filters + self.filters)
        ) if self.filters else or_(*filters)

        count_stmt = select(func.count()).select_from(self.model)
        if joins:
            for model_to_join, on_clause in joins:
                count_stmt = count_stmt.join(model_to_join, on_clause)

        count_stmt = count_stmt.where(combined_where)
        total_records = self.session.scalar(count_stmt)

        stmt = stmt.where(combined_where).order_by(
            self.model.id
        ).offset(skip).limit(limit)
        rows = self.session.scalars(stmt).all()
        total_pages = ceil(total_records / page_size) if total_records else 1

        return self._format_response(
            rows, total_records, page, page_size, total_pages
        )

    def _format_response(  # noqa: PLR6301
        self,
        rows,
        total_records,
        page,
        page_size,
        total_pages
    ):
        start_page = max(1, page - 2)
        end_page = min(total_pages, start_page + 4)

        """Formata a resposta para um padrão consistente."""
        return {
            "rows": rows,
            "total_records": total_records,
            "current_page": page,
            "page_size": page_size,
            "total_pages": total_pages,
            "start_page": start_page,
            "end_page": end_page,
        }


class UserRepository(
    BaseRepository[
        User,
        Session,
        UserInSchema,
        UserUpdate
    ]
):
    def __init__(self, session: Session, user: User = None):
        super().__init__(User, session, user)

    async def create(self, obj_in: UserInSchema) -> User:
        # verify_user_with_roles_and_permissions(user_current, permissions=["is_superuser"])
        db_user = self.session.scalar(
            select(self.model).where(
                (self.model.email == obj_in.email) | (self.model.username == obj_in.username)
            )
        )
        if db_user:
            if db_user.email == obj_in.email:
                raise HTTPException(
                    status_code=HTTPStatus.CONFLICT,
                    detail='Email already registered',
                )
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail='Username already registered',
            )

        padrao = "Coletiva@" + str(datetime.now().year)
        hashed_password = get_password_hash(padrao)

        try:
            obj = self.model(
                **obj_in.model_dump()
            )
            obj.otp_created_at = get_data_now_for_time_zone()
            obj.password = hashed_password

            self.session.add(obj)
            self.session.commit()
            self.session.refresh(obj)
            return obj

        except IntegrityError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.CONFLICT,
                detail=f"Conflito de integridade: {str(e.orig)}"
            )
        except SQLAlchemyError as e:
            self.session.rollback()
            raise HTTPException(
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                detail="Erro interno no banco de dados."
            )

    async def update(self, db_obj: User, obj_in: UserUpdate) -> User:
        """
        medo de atualização de usuário sera feito por outros metodos
        """
        raise NotImplementedError("Método create não deve ser implementado")

    async def update_user(self, obj_in: User) -> User:
        """
        atualiza o usuario
        REGRA1: somente super user pode alterar outro usuario
        REGRA2: usuario pode alterar sua propria senha
        """
        row = await self.get(obj_in.id)

        if row.id != obj_in.id and not self.is_permite():
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail='Você não tem permissão para atualizar o usuário'
            )

        # Atualiza os campos normais (exceto a senha)
        for key, value in obj_in.model_dump(exclude_unset=True).items():
            if key in {"password", "last_login", "created_at", "updated_at"}:
                continue
            current_value = getattr(row, key)
            if current_value != value:
                setattr(row, key, value)

        self.session.add(row)
        self.session.commit()
        return row

    async def update_password(
        self,
        db_obj: User,
        new_password: str,
        password: str | None
    ) -> User:
        """
        atualiza a senha do usuario
        REGRA1: somente super user pode alterar senhas de outro usuario
        REGRA2: usuario pode alterar sua propria senha
        REGRA3: usuario pode alterar sua propria com a senha anterior
        """

        # REGRA1
        if self.user.id != db_obj.id and not self.is_permite():
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail='Você não tem permissão para atualizar a senha \
                    de outro usuário'
            )

        # REGRA2
        if (
            not db_obj.is_superuser
            and not password and not self.user.is_superuser
        ):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail='Senhas Anteriro obrigatória',
            )

        # REGRA3
        if password:
            if not verify_password(password, db_obj.password):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail='Senha atual inválida',
                )

        if not User.validar_senha(new_password):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail='verificar se a senha contém pelo menos uma letra \
                    maiúscula e um caractere especial',
            )

        db_obj.password = get_password_hash(new_password)
        self.session.commit()
        self.session.refresh(db_obj)
        return db_obj


class ModuloRepository(
    BaseRepository[
        Module,
        Session,
        ModuleInSchema,
        ModuleOutSchema
    ]
):
    def __init__(self, session: Session, user: User | None):
        super().__init__(Module, session, user)

    async def delete(self, id: int):
        """
        so permiter excluir se for o usuario superuser e não utilizado
        """
        # obj = await self.get(id)

        if not self.is_permite():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail='Você não tem permissão para excluir'
            )
        return await super().delete(id)


class PerfilRepository(
    BaseRepository[
        Role,
        Session,
        RoleInSchema,
        RoleOutSchema
    ]
):
    def __init__(self, session: Session, user: User | None):
        super().__init__(Role, session, user)

    async def delete(self, id: int):
        """
        so permiter excluir se for o usuario superuser e não utilizado
        """
        # obj = await self.get(id)

        if not self.is_permite():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail='Você não tem permissão para excluir'
            )
        return await super().delete(id)


class RolePermissionsRepository(
    BaseRepository[
        RolePermissions,
        Session,
        PerfilPermissaoInSchema,
        PerfilPermissaoOutSchema
    ]
):
    """
    gestao de permissões de perfil
    """
    def __init__(self, session: Session, user: User | None):
        super().__init__(RolePermissions, session, user)

    async def delete(self, id: int):
        """
        so permiter excluir se for o usuario superuser e não utilizado
        """
        # obj = await self.get(id)

        if not self.is_permite():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail='Você não tem permissão para excluir'
            )
        return await super().delete(id)
