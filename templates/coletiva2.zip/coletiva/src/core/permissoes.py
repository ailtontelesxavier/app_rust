from fastapi import HTTPException, status

from core.base import T_ParamsBase
from core.repositories import BaseRepository


def verificar_permissao(
    base: T_ParamsBase,
) -> bool:
    """
    Verifica se o usuário tem a permissão necessária.

    dependencies=[Depends(verificar_permissao)]
    sem passar permissons verifica se é super usuario
    """
    rep = BaseRepository(model=None, session=base.session, user=base.user)
    if not rep.is_permite(permissions=['is_superuser']):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Você não tem permissão para acessar este recurso."
        )
    return True
