from core.base import T_ParamsBase


@router.get("/module-api", response_model=ModuleListSchema)
async def get_module_api(
    base: T_ParamsBase,
    find: str | None = None,
    page: int = 1,
    page_size: int = 10,
):
    # verify_user_with_roles_and_permissions
    # (user, permissions=["view_externo_solitacao_contato"])
    skip = (page - 1) * page_size
    limit = page_size

    if not find:
        db_rows = (
            base.session.query(Module)
            .order_by(Module.id.desc())
            .offset(skip)
            .limit(limit)
            .all()
        )
        total_records = base.session.scalar(
            base.session.query(func.count(Module.id))
        )
    else:
        partial_name = f"%{find}%"

        db_rows = (
            base.session.query(Module)
            .where(
                or_(
                    Module.title.ilike(partial_name),
                )
            )
            .order_by(Module.id.desc())
            .offset(skip)
            .limit(limit)
        )

        total_records = base.session.scalar(
            base.session.query(func.count(Module.id)).where(
                or_(
                    Module.title.ilike(partial_name),
                )
            )
        )

    total_pages = ceil(total_records / page_size) if total_records else 1

    return {
        "rows": db_rows,
        "total_records": total_records,
        "total_pages": total_pages,
        "current_page": page,
    }