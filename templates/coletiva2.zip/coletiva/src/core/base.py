from http import HTTPStatus
from typing import Annotated

from cachetools import TTLCache
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from core.database import get_session
from core.models import (
    User,
)
from core.security import get_current_user
from core.settings import get_settings

T_Session = Annotated[Session, Depends(get_session)]
T_CurrentUser = Annotated[User, Depends(get_current_user)]

settings = get_settings()


# 30 minutos × 60 segundos = 1800 segundos
cache = TTLCache(maxsize=1, ttl=1800)


def get_dominio_cnpj_map(consultar: bool = False):
    if "dominios" in cache and not consultar:
        return cache["dominios"]
    else:
        # busca o domínio
        from externo.views_api import get_portal_router  # noqa: PLC0415
        response = get_portal_router()
        cache["dominios"] = response
        return response


class ParamsBase:
    """
    """
    def __init__(
        self,
        request: Request,
        session: T_Session,
        user: T_CurrentUser
    ):
        self.request = request
        self.session = session
        self.user = user
        self.session.info["current_user_id"] = user.id


class Base:
    """
    """
    def __init__(
        self,
        request: Request,
    ):
        self.request = request
        self.cnpj = None

        # Pegando o IP do cliente
        self.client_ip = request.client.host

        # Se estiver atrás de um proxy, use X-Forwarded-For
        if "X-Forwarded-For" in request.headers:
            self.client_ip = request.headers["X-Forwarded-For"].split(",")[0]

        # verificar se está em HTTP ou HTTPS

        if settings.DEBUG:
            self.base_url = str(request.base_url)
        else:
            self.base_url = str(request.base_url).replace("http://", "https://")

        # Monta domínio acessado
        forwarded_proto = (
            request.headers.get("x-forwarded-proto", "http")
            or request.headers.get("x-forwarded-proto", "https")
        )
        host = request.headers.get("host")
        full_domain = f"{forwarded_proto}://{host}"
        dominios = get_dominio_cnpj_map()

        for tentativa in range(3):
            # consultar se está fazendo algum roteamente automatico de CNPJ por DNS
            for item in dominios:
                if item["dns"].lower() == full_domain.lower():
                    self.cnpj = item["cnpj"]
                    break
            if not self.cnpj and (not 'localhost' in host):
                dominios = get_dominio_cnpj_map(consultar=True)

        # sempre pegar cnpj do .env se debug true
        if settings.DEBUG:
            self.cnpj = settings.CLIENT_ID  # None

        # dns não encontrado
        if not self.cnpj:
            raise HTTPException(
                status_code=HTTPStatus.NOT_FOUND,
                detail="DNS não encontrado"
            )

        print("CNPJ: >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", self.cnpj)


class ParamsPaginacao:
    """Dependecia para paginacao"""
    def __init__(
            self,
            find: str = None,
            page: int = 1,
            page_size: int = 10,
        ):
        self.find = find
        self.page = page
        self.page_size = page_size
        self.skip = (page - 1) * page_size
        self.limit = page_size


T_ParamsBase = Annotated[ParamsBase, Depends(ParamsBase)]
T_ParamsPaginacao = Annotated[ParamsPaginacao, Depends(ParamsPaginacao)]

T_Base = Annotated[Base, Depends(Base)]
