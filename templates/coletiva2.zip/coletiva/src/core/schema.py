from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr

from .models import User


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: str | None = None


class UserInSchema(BaseModel):
    username: str
    full_name: str
    email: EmailStr
    password: str | None = None
    full_name: str
    is_active: bool | None = False
    is_staff: bool | None = False
    is_superuser: bool | None = False
    otp_base32: str | None = User.create_otp_base32()
    otp_auth_url: str | None = None
    otp_created_at: datetime | None = None
    password: str | None = None


class UserUpdate(UserInSchema):
    id: int
    username: str | None = None
    full_name: str | None = None
    email: EmailStr | None = None
    password: str | None = None
    is_active: bool | None = None
    is_staff: bool | None = None
    is_superuser: bool | None = None


class UpdatePasswordRequest(BaseModel):
    password: Optional[str] | None = None
    new_password: str


class ModuleInSchema(BaseModel):
    title: str


class ModuleOutSchema(ModuleInSchema):
    id: int


class ModuleListSchema(BaseModel):
    rows: list[ModuleOutSchema]
    total_records: int
    total_pages: int
    current_page: int


class ModuleList(BaseModel):
    rows: list[ModuleOutSchema]
    total_records: int


class PermissionSchema(BaseModel):
    name: str
    description: str | None = None
    module_id: int


class PermissionOutSchema(PermissionSchema):
    id: int


class PermissaoListSchema(BaseModel):
    rows: list[PermissionOutSchema]
    total_records: int
    total_pages: int
    current_page: int


class RoleInSchema(BaseModel):
    name: str


class RoleOutSchema(BaseModel):
    id: int
    name: str


class RoleFull(BaseModel):
    id: int
    name: str
    permissions: list['PermissionOutSchema']


class RoleListSchema(BaseModel):
    rows: list[RoleOutSchema]
    total_records: int
    total_pages: int
    current_page: int


class PerfilPermissaoInSchema(BaseModel):
    role_id: int
    permission_id: int


class PerfilPermissaoOutSchema(PerfilPermissaoInSchema):
    id: int
    role: RoleOutSchema | None = None
    permission: PermissionOutSchema | None = None


class PerfilPermissaoListSchema(BaseModel):
    rows: list[PerfilPermissaoOutSchema]
    total_records: int
    total_pages: int
    current_page: int


class UserInSchema(BaseModel):
    username: str
    full_name: str
    email: EmailStr
    password: str
    full_name: str
    is_active: bool
    is_staff: bool
    is_superuser: bool


class UserOutSchema(UserInSchema):
    id: int


class UserPublic(BaseModel):
    id: int
    username: str
    full_name: str
    email: EmailStr
    full_name: str
    is_active: bool
    is_staff: bool
    is_superuser: bool


class UserListSchema(BaseModel):
    rows: list[UserOutSchema]
    total_records: int
    total_pages: int
    current_page: int


class UserFull(UserPublic):
    created_at: datetime
    updated_at: datetime


class UserRolesIn(BaseModel):
    user_id: int
    role_id: int


class UserRolesOut(UserRolesIn):
    id: int
    role: RoleOutSchema
    user: UserOutSchema


class UserRolesList(BaseModel):
    rows: list[UserRolesOut]
    total_records: int
    total_pages: int
    current_page: int
