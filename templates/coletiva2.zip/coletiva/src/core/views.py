from http import HTTPStatus
from math import ceil

from fastapi import (
    APIRouter,
    Body,
    Depends,
    FastAPI,
    HTTPException,
    Request,
    status,
)
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from markupsafe import Markup
from sqlalchemy import and_, func, or_, select

from core.models import Module, Permission, Role, RolePermissions, User, UserRoles
from core.permissoes import verificar_permissao
from util import get_column_names, get_data_now_for_time_zone

from .base import T_ParamsBase, T_ParamsPaginacao
from .repositories import ModuloRepository, PerfilRepository, RolePermissionsRepository, UserRepository
from .schema import (
    ModuleInSchema,
    ModuleListSchema,
    ModuleOutSchema,
    PerfilPermissaoInSchema,
    PerfilPermissaoListSchema,
    PerfilPermissaoOutSchema,
    PermissaoListSchema,
    PermissionOutSchema,
    PermissionSchema,
    RoleInSchema,
    RoleListSchema,
    RoleOutSchema,
    UpdatePasswordRequest,
    UserListSchema,
    UserRolesIn,
    UserRolesList,
    UserRolesOut,
)

templates = Jinja2Templates(directory="src/templates")


router = FastAPI(
    title="Core",
    description="base systema",
    route_class=APIRouter(prefix="/core", tags=["core"]),
)


@router.get(
    "/modulo",
    response_class=HTMLResponse,
    name="modulo-list",
    dependencies=[Depends(verificar_permissao)]
)
async def get_tipo(
    base: T_ParamsBase,
    pag: T_ParamsPaginacao,
):
    """Renderiza a lista de modulos."""

    rep = ModuloRepository(base.session, base.user)

    result = await rep.get_paginated(
        find=pag.find,
        page=pag.page,
        page_size=pag.page_size,
        search_fields=["nome"]
    )

    # column_names = get_column_names(module)
    column_names = ["id", "title"]

    headers = ["ID", "Nome", "Ações"]

    return templates.TemplateResponse(
        "core/modulo.html",
        {
            "request": base.request,
            "column_names": column_names,
            "headers": headers,
            **result
        }
    )


@router.get(
    "/modulo/",
    response_class=HTMLResponse,
    name="modulo-form"
)
async def get_modulo_form(base: T_ParamsBase):
    """Renderiza o formulário de modulo."""
    return templates.TemplateResponse(
        "core/modulo_form.html",
        {
            "request": base.request,
        }
    )


@router.get("/modulo/{id}", response_class=HTMLResponse)
async def get_modulo(
    base: T_ParamsBase,
    id: int
):
    """Renderiza o modulo específico."""
    rep = ModuloRepository(base.session, base.user)

    result = await rep.get(id)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail="modulo não encontrado"
        )

    return templates.TemplateResponse(
        "core/modulo_form.html",
        {
            "request": base.request,
            "row": result,
        }
    )


@router.post(
    "/modulo/",
    status_code=status.HTTP_201_CREATED,
    response_model=ModuleOutSchema
)
async def post_modulo(
    base: T_ParamsBase,
    modulo: ModuleInSchema
):
    """Cria um novo modulo."""
    rep = ModuloRepository(base.session, base.user)

    result = await rep.create(modulo)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail="Erro ao criar modulo"
        )

    return result


@router.put(
    "/modulo/{id}",
    status_code=status.HTTP_200_OK,
    response_model=ModuleOutSchema
)
async def put_modulo(
    base: T_ParamsBase,
    id: int,
    modulo: ModuleOutSchema
):
    """Atualiza um modulo existente."""
    rep = ModuloRepository(base.session, base.user)

    if id != modulo.id:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail="ID do modulo não corresponde ao ID fornecido"
        )

    result = await rep.update(modulo)

    if not result:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail="modulo não encontrado"
        )

    return result


@router.delete("/modulo/{module_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_module(
    base: T_ParamsBase,
    module_id: int,
):
    rep = ModuloRepository(base.session, base.user)

    return await rep.delete(module_id)


# ################################################################
# ========================= USER  ========================= #
# ################################################################
@router.put('/update-password/{user_id}')
async def update_user_password(
    base: T_ParamsBase,
    user_id: int,
    form: UpdatePasswordRequest = Body(...),
):
    rep = UserRepository(base.session, base.user)

    db_user = await rep.get(user_id)
    if db_user is None:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail='User not found',
        )

    db_user = await rep.update_password(
        db_user,
        form.new_password,
        form.password
    )

    return {'message': 'Senha atualizada'}


@router.put(
    '/update-otp/{user_id}',
    dependencies=[Depends(verificar_permissao)]
)
async def update_otp_user_by_id(
    user_id: int,
    base: T_ParamsBase
):
    """
    permite atualizar o OTP do usuario somente para super user
    """
    db_user = base.session.scalar(select(User).where(User.id == user_id))

    if not db_user:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND, detail='User not found.'
        )

    try:
        setattr(db_user, 'otp_base32', User.create_otp_base32())
        setattr(db_user, 'otp_created_at', get_data_now_for_time_zone())

        setattr(db_user, 'verificar_permissao', func.now())
        setattr(db_user, 'otp_auth_url', db_user.get_otp_auth_url())
        setattr(db_user, 'qr_code', str(db_user.get_qr_code()))

        base.session.commit()
        base.session.refresh(db_user)
    except Exception as e:
        print(f'Erro ao update otp: {e}')
        raise

    return {'message': 'OTP atualizado com sucesso'}


# ################################################################
# ======================= Settings ============================ #
# ################################################################
@router.get("/senha-form", response_class=HTMLResponse)
async def get_senha_form(pr: T_ParamsBase):
    """
    utilizado para alterar a senha do usuario logado
    """

    return templates.TemplateResponse(
        "core/settings/senha_form.html",
        {
            "request": pr.request,
            "user": pr.user
        }
    )


# ################################################################
# ======================= PERMISSOES =========================== #
# ################################################################
@router.get(
    "/permissao",
    response_class=HTMLResponse,
    dependencies=[Depends(verificar_permissao)]
)
async def get_permissao(
    base: T_ParamsBase,
    find: str | None = None,
    page: int = 1,
    page_size: int = 10,
):
    skip = (page - 1) * page_size
    limit = page_size

    if not find:
        db_rows = (
            base.session.query(Permission)
            .order_by(Permission.id.desc())
            .offset(skip)
            .limit(limit)
            .all()
        )
        total_records = base.session.scalar(
            base.session.query(func.count(Permission.id))
        )
    else:
        partial_name = f"%{find}%"

        db_rows = (
            base.session.query(Permission)
            .where(
                or_(
                    Permission.name.ilike(partial_name),
                )
            )
            .order_by(Permission.id.desc())
            .offset(skip)
            .limit(limit)
        )

        total_records = base.session.scalar(
            base.session.query(func.count(Permission.id)).where(
                or_(
                    Permission.name.ilike(partial_name),
                )
            )
        )

    total_pages = ceil(total_records / page_size) if total_records else 1
    headers = ["ID", "Nome", "Módulo", "Ações"]
    rows = [
        [permission.id, permission.name, permission.module.title]
        for permission in db_rows
    ]

    start_page = max(1, page - 2)
    end_page = min(total_pages, start_page + 4)

    column_names = get_column_names(Module)

    return templates.TemplateResponse(
        "core/permissao.html",
        {
            "request": base.request,
            "headers": headers,
            "rows": rows,
            "total_records": total_records,
            "total_pages": total_pages,
            "current_page": page,
            "start_page": start_page,
            "end_page": end_page,
            'column_names': column_names
        }
    )


@router.get(
    "/permissao-api",
    response_model=PermissaoListSchema,
    dependencies=[Depends(verificar_permissao)]
)
async def get_permissao_api(
    base: T_ParamsBase,
    find: str | None = None,
    page: int = 1,
    page_size: int = 10,
):
    skip = (page - 1) * page_size
    limit = page_size

    if not find:
        db_rows = (
            base.session.query(Permission)
            .order_by(Permission.id.desc())
            .offset(skip)
            .limit(limit)
            .all()
        )
        total_records = base.session.scalar(
            base.session.query(func.count(Permission.id))
        )
    else:
        partial_name = f"%{find}%"

        db_rows = (
            base.session.query(Permission)
            .where(
                or_(
                    Permission.name.ilike(partial_name),
                )
            )
            .order_by(Permission.id.desc())
            .offset(skip)
            .limit(limit)
        )

        total_records = base.session.scalar(
            base.session.query(func.count(Permission.id)).where(
                or_(
                    Permission.name.ilike(partial_name),
                )
            )
        )

    total_pages = ceil(total_records / page_size) if total_records else 1

    return {
        "rows": db_rows,
        "total_records": total_records,
        "total_pages": total_pages,
        "current_page": page,
    }


@router.delete(
    "/permissao/{permissao_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(verificar_permissao)]
)
async def delete_permissao(
    base: T_ParamsBase,
    permissao_id: int,
):
    row = base.session.get(Permission, permissao_id)

    if row is None:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND, detail='Permissão não encontrado'
        )

    base.session.delete(row)
    base.session.commit()

    return {}


@router.get("/permissao-form", response_class=HTMLResponse)
async def get_permissao_form(request: Request):
    return templates.TemplateResponse(
        "core/permissao_form.html",
        {"request": request}
    )


@router.get(
    "/permissao-form/{permissao_id}",
    response_class=HTMLResponse,
    dependencies=[Depends(verificar_permissao)]
)
async def get_permissao_id(
    base: T_ParamsBase,
    permissao_id: int,
):

    db_row = base.session.get(Permission, permissao_id)

    if db_row is None:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND, detail='Permissão não encontrada'
        )

    return templates.TemplateResponse(
        "core/permissao_form.html",
        {
            "request": base.request,
            "row": db_row,
        }
    )


@router.post(
    "/permissao-form",
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(verificar_permissao)]
)
async def post_permissao_form(
    base: T_ParamsBase,
    permissao: PermissionSchema,
):
    row = base.session.scalars(select(Permission).where(
        and_(
            Permission.name == permissao.name,
            Permission.module_id == permissao.module_id
        )
    )).first()

    if row:
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT, detail='Permissão já cadastrada'
        )

    row = Permission(
        name=permissao.name,
        description=permissao.description,
        module_id=permissao.module_id
    )

    base.session.add(row)
    base.session.commit()
    base.session.refresh(row)
    return row


@router.put(
    "/permissao-form/{permissao_id}",
    response_model=PermissionOutSchema,
    dependencies=[Depends(verificar_permissao)]
)
async def put_permissao_form(
    base: T_ParamsBase,
    permissao_id: int,
    permissao: PermissionOutSchema,
):

    row = base.session.get(Permission, permissao_id)

    if permissao_id != row.id:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST, detail='ID do permissão diferente'
        )

    for key, value in permissao.model_dump(exclude_unset=True).items():
        current_value = getattr(row, key)
        if current_value != value:
            setattr(row, key, value)

    base.session.add(row)
    base.session.commit()
    base.session.refresh(row)

    return row


# ################################################################
# ======================= PERMISSOES =========================== #
# ################################################################
@router.get(
    "/perfil",
    response_class=HTMLResponse,
    dependencies=[Depends(verificar_permissao)]
)
async def get_perfil(
    base: T_ParamsBase,
    page: T_ParamsPaginacao
):
    rep = PerfilRepository(base.session, base.user)

    result = await rep.get_paginated(
        find=page.find,
        page=page.page,
        page_size=page.page_size,
        search_fields=["name"]
    )

    headers = ["ID", "Nome", "Ações"]
    rows = [
        [perfil.id, perfil.name]
        for perfil in result.get('rows')
    ]

    # column_names = get_column_names(Role)
    column_names = ["id", "name"]

    return templates.TemplateResponse(
        "core/perfil.html",
        {
            "request": base.request,
            "headers": headers,
            "rows": rows,
            "column_names": column_names,
            **result,
        }
    )


@router.delete("/perfil/{perfil_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_perfil(
    base: T_ParamsBase,
    perfil_id: int,
):

    rep = PerfilRepository(base.session, base.user)

    row = await rep.get(perfil_id)

    if row is None:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND, detail='Perfil não encontrado'
        )

    await rep.delete(perfil_id)

    return {}


@router.get("/perfil-form", response_class=HTMLResponse)
async def get_perfil_form(request: Request):
    return templates.TemplateResponse(
        "core/perfil_form.html",
        {"request": request}
    )


@router.get("/perfil-form/{perfil_id}", response_class=HTMLResponse)
async def get_perfil_id(
    base: T_ParamsBase,
    perfil_id: int,
):

    rep = PerfilRepository(base.session, base.user)

    row = await rep.get(perfil_id)

    if row is None:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND, detail='Permissão não encontrada'
        )

    return templates.TemplateResponse(
        "core/perfil_form.html",
        {
            "request": base.request,
            "perfil": row,
        }
    )


@router.post("/perfil-form", status_code=status.HTTP_201_CREATED)
async def post_perfil_form(
    base: T_ParamsBase,
    perfil: RoleInSchema,
):

    rep = PerfilRepository(base.session, base.user)

    filters = []
    filters.append(rep.model.name == perfil.name)

    result = await rep.get_by_filters(filters)

    if result.get('rows'):
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT, detail='Permissão já cadastrada'
        )

    row = await rep.create(perfil)

    return row


@router.put(
    "/perfil-form/{perfil_id}",
    response_model=RoleOutSchema)
async def put_perfil_form(
    base: T_ParamsBase,
    perfil_id: int,
    perfil: RoleOutSchema,
):

    if perfil_id != perfil.id:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST, detail='ID do perfil diferente'
        )
    rep = PerfilRepository(base.session, base.user)

    row = await rep.update(perfil)

    return row


@router.get("/perfil-api", response_model=RoleListSchema)
async def get_perfil_api(
    base: T_ParamsBase,
    page: T_ParamsPaginacao
):

    rep = PerfilRepository(base.session, base.user)

    result = await rep.get_paginated(
        find=page.find,
        page=page.page,
        page_size=page.page_size,
        search_fields=["name"]
    )

    return {
        **result,
    }


# ################################################################
# ===================== GESTAO PERFIL ========================= #
# ################################################################
@router.get("/perfil-gestao", response_class=HTMLResponse)
async def get_perfil_gestao(request: Request):
    return templates.TemplateResponse(
        "core/perfil_gestao.html",
        {"request": request}
    )


@router.post(
    '/perfil-permissao',
    status_code=HTTPStatus.CREATED,
    response_model=PerfilPermissaoOutSchema,
)
async def post_role_permission(
    role_permission: PerfilPermissaoInSchema,
    base: T_ParamsBase
):

    rep = RolePermissionsRepository(base.session, base.user)

    filters = []
    filters.append(rep.model.permission_id == role_permission.permission_id)
    filters.append(rep.model.role_id == role_permission.role_id)

    row = await rep.get_by_filters(filters=filters)

    if row.get('rows'):
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT,
            detail='Pefil permission ja cadastrado',
        )

    row = await rep.create(role_permission)

    return row


@router.get(
    "/permissao-por-perfil/{perfil_id}",
    response_model=PerfilPermissaoListSchema
)
async def get_permissao_por_perfil(
    base: T_ParamsBase,
    perfil_id: int,
    page: int = 1,
    page_size: int = 10,
):

    skip = (page - 1) * page_size
    limit = page_size

    query = base.session.query(RolePermissions).where(
        RolePermissions.role_id == perfil_id
    )

    rows = (
        query
        .order_by(RolePermissions.id.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    total_records = base.session.scalar(
        select(func.count()).select_from(query.subquery())
    )

    total_pages = ceil(total_records / page_size) if total_records else 1

    start_page = max(1, page - 2)
    end_page = min(total_pages, start_page + 4)

    return {
        "rows": rows,
        "total_records": total_records,
        "total_pages": total_pages,
        "current_page": page,
        "start_page": start_page,
        "end_page": end_page,
    }


@router.delete(
    "/permissao-por-perfil/{permissao_perfil_id}",
    status_code=status.HTTP_204_NO_CONTENT
)
async def delete_permissao_por_perfil(
    base: T_ParamsBase,
    permissao_perfil_id: int,
):

    rep = RolePermissionsRepository(base.session, base.user)

    row = await rep.get(permissao_perfil_id)

    if row is None:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND, detail='Perfil não encontrado'
        )

    await rep.delete(permissao_perfil_id)

    return {}


# ################################################################
# ======================= USER PERFIL ========================== #
# ################################################################
@router.get("/user-gestao-perfil", response_class=HTMLResponse)
async def get_user_gestao_perfil(request: Request):
    return templates.TemplateResponse(
        "core/user_perfil.html",
        {"request": request}
    )


@router.get("/user-api", response_model=UserListSchema)
async def get_user_api(
    base: T_ParamsBase,
    pag: T_ParamsPaginacao,
    find: str | None = None,
    page: int = 1,
    page_size: int = 10,
):
    """
    nao colocar permissao pois utilizado pelo componente
    so usuario logado.

     rep = UserRepository(base.session, base.user)

    filters = []
    filters.append(User.full_name.ilike(page.find))
    filters.append(User.username.ilike(page.find))

    rep.filters = filters

    result = await rep.get_paginated(
        find=page.find,
        search_fields=["full_name", "username"]
    )

    return {
        **result,
    }
    """

    skip = (page - 1) * page_size
    limit = page_size

    if not find:
        db_rows = (
            base.session.query(User)
            .order_by(User.id.desc())
            .offset(skip)
            .limit(limit)
            .all()
        )
        total_records = base.session.scalar(
            base.session.query(func.count(User.id))
        )
    else:
        partial_name = f"%{find}%"

        query = base.session.query(User).where(
                or_(
                    User.full_name.ilike(partial_name),
                    User.username.ilike(partial_name),
                )
            )

        db_rows = (
            query
            .order_by(User.id.desc())
            .offset(skip)
            .limit(limit)
        )

        total_records = base.session.scalar(
            select(func.count()).select_from(query.subquery())
        )

    total_pages = ceil(total_records / page_size) if total_records else 1

    return {
        "rows": db_rows,
        "total_records": total_records,
        "total_pages": total_pages,
        "current_page": page,
    }


@router.get(
    "/user-gestao-perfil/{user_id}",
    response_model=UserRolesList
)
async def get_perfil_user(
    base: T_ParamsBase,
    user_id: int,
    page: int = 1,
    page_size: int = 10,
):

    skip = (page - 1) * page_size
    limit = page_size

    query = base.session.query(UserRoles).where(
        UserRoles.user_id == user_id
    )

    rows = (
        query
        .order_by(UserRoles.id.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    total_records = base.session.scalar(
        select(func.count()).select_from(query.subquery())
    )

    total_pages = ceil(total_records / page_size) if total_records else 1

    return {
        "rows": rows,
        "total_records": total_records,
        "total_pages": total_pages,
        "current_page": page,
    }


@router.post(
    '/user-gestao-perfil',
    status_code=HTTPStatus.CREATED,
    response_model=UserRolesOut,
)
def post_perfil_user(
    user_role: UserRolesIn,
    base: T_ParamsBase
):
    db_row = base.session.scalar(
        select(UserRoles).where(
            (UserRoles.role_id == user_role.role_id)
            & (
                UserRoles.user_id
                == user_role.user_id
            )
        )
    )

    if db_row:
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT,
            detail='Pefil permission ja cadastrado',
        )

    db_row = UserRoles(
        role_id=user_role.role_id,
        user_id=user_role.user_id,
    )

    base.session.add(db_row)
    base.session.commit()
    base.session.refresh(db_row)
    return db_row


@router.delete(
    "/user-gestao-perfil/{perfil_user_id}",
    status_code=status.HTTP_204_NO_CONTENT
)
async def delete_perfil_user(
    base: T_ParamsBase,
    perfil_user_id: int,
):

    row = base.session.get(UserRoles, perfil_user_id)

    if row is None:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND, detail='Permissão não encontrado'
        )

    base.session.delete(row)
    base.session.commit()

    return {}


# ################################################################
# ======================= APIs =========================== #
# ################################################################


@router.get("/module-api", response_model=ModuleListSchema)
async def get_module_api(
    base: T_ParamsBase,
    find: str | None = None,
    page: int = 1,
    page_size: int = 10,
):
    # verify_user_with_roles_and_permissions
    # (user, permissions=["view_externo_solitacao_contato"])
    skip = (page - 1) * page_size
    limit = page_size

    if not find:
        db_rows = (
            base.session.query(Module)
            .order_by(Module.id.desc())
            .offset(skip)
            .limit(limit)
            .all()
        )
        total_records = base.session.scalar(
            base.session.query(func.count(Module.id))
        )
    else:
        partial_name = f"%{find}%"

        db_rows = (
            base.session.query(Module)
            .where(
                or_(
                    Module.title.ilike(partial_name),
                )
            )
            .order_by(Module.id.desc())
            .offset(skip)
            .limit(limit)
        )

        total_records = base.session.scalar(
            base.session.query(func.count(Module.id)).where(
                or_(
                    Module.title.ilike(partial_name),
                )
            )
        )

    total_pages = ceil(total_records / page_size) if total_records else 1

    return {
        "rows": db_rows,
        "total_records": total_records,
        "total_pages": total_pages,
        "current_page": page,
    }
