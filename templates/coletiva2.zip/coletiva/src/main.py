import json
import os
from contextlib import asynccontextmanager
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from typing import Annotated

import uvicorn
from fastapi import (
    Depends,
    FastAPI,
    # File,
    HTTPException,
    Request,
    # UploadFile,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
)
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# from fastapi.middleware.httpsredirect import HTTPSRedirectMiddleware
# from fastapi.middleware.trustedhost import TrustedHostMiddleware
from prometheus_fastapi_instrumentator import Instrumentator

# from itsdangerous import URLSafeSerializer
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import logger, logging
from .coletiva.views import router as coletiva_router
from .core.database import get_session
from .core.models import Module, Permission, Role, User, UserRoles
from .core.schema import ModuleList
from .core.security import (
    create_access_token,
    get_current_user,
    verify_password,
)
from .core.settings import get_settings
from .core.views import router as core_router
from .externo.views import router as externo_router
from .middleware import RoleCheckMiddleware

T_Session = Annotated[Session, Depends(get_session)]
T_CurrentUser = Annotated[User, Depends(get_current_user)]

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    if settings.env == "development":
        print("🚀 Ambiente de desenvolvimento")
    else:
        print("🔒 Ambiente de produção")
    yield


app = FastAPI(lifespan=lifespan, version="0.0.1")

Instrumentator().instrument(app).expose(app)

app.mount("/static", StaticFiles(directory="src/static"), name="static")

# Serve logotipos em /logotipos/*
app.mount(
    "/logotipos",
    StaticFiles(directory="src/uploads/logotipos"),
    name="logotipos"
)


templates = Jinja2Templates(directory="src/templates")

# Log para Graylog
# logger = logging.getLogger("uvicorn")
logger.setLevel(os.getenv("LOG_LEVEL", "info").upper())
handler = logging.StreamHandler()
formatter = logging.Formatter('[%(levelname)s] %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

origins = [
    'http://localhost:8004',
    'https://localhost:8004',
    'http://*.portalacaocoletiva.com.br',
    'https://*.portalacaocoletiva.com.br',
    'http://127.0.0.1:8000',
    'http://portal-acs:8000',
    'http://172.18.0.16:8000',
    'http://127.0.0.1:8000',
]

# Adicionar o middleware de CSRF
# app.add_middleware(CSRFMiddleware)


# app.add_middleware(HTTPSRedirectMiddleware)


app.add_middleware(RoleCheckMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

# app.add_middleware(
#     TrustedHostMiddleware,
#     allowed_hosts=["fomento.to.gov.br", "*.fomento.to.gov.br"]
# )


@app.middleware('http')
async def redirect_unauthorized_requests(request: Request, call_next):
    response = await call_next(request)
    if response.status_code == status.HTTP_401_UNAUTHORIZED:
        return RedirectResponse(url="/login")
    elif response.status_code == status.HTTP_403_FORBIDDEN:
        return templates.TemplateResponse(
            "403.html", {"request": request}, status_code=403)
    elif response.status_code == status.HTTP_404_NOT_FOUND:
        return templates.TemplateResponse(
            "404.html", {"request": request}, status_code=404)
    return response


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return FileResponse("static/favicon.ico")


@app.get("/login", status_code=status.HTTP_401_UNAUTHORIZED)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.post('/login')
async def login_for_access_token(
    response: JSONResponse,
    form_data: OAuth2PasswordRequestForm = Depends(),
    session: Session = Depends(get_session),
):
    modules = []
    permissions = []

    user = session.scalar(
        select(User).where(User.username == form_data.username)
    )

    if not user:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail='Incorrect username or password',
        )

    if not user.is_active:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail='Incorrect status, username or password',
        )

    if not verify_password(form_data.password, user.password):
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail='Incorrect username or password',
        )

    # Verifica se o usuário tem autenticação de dois fatores habilitada
    # if not user.is_valid_otp(form_data.client_secret):  # type: ignore
    #     raise HTTPException(
    #         status_code=HTTPStatus.BAD_REQUEST,
    #         detail='Incorrect username, password or secret',
    #     )

    access_token = create_access_token(
        data={
            'sub': user.username,
            'is_superuser': user.is_superuser
        }
    )

    logger.debug("Login realizado com sucesso!")

    user.last_login = func.now()

    session.add(user)
    session.commit()

    # ####### obterm acessos ##########

    if user.is_superuser:
        modules = session.scalars(
            select(Module)
        ).all()
    else:
        # Obtém as roles do usuário atual
        user_roles = session.scalars(
            select(UserRoles).where(UserRoles.user_id == user.id)
        ).all()

        # Coleta os IDs das roles
        role_ids = [user_role.role_id for user_role in user_roles]

        if not role_ids:
            raise HTTPException(
                status_code=status.HTTP_424_FAILED_DEPENDENCY,
                detail='No roles found for this user.'
            )

        # Obtém as permissões associadas às roles
        permissions = session.scalars(
            select(Permission).join(
                Role.permissions
            ).where(Role.id.in_(role_ids))
        ).all()

        if not permissions:
            raise HTTPException(
                status_code=404,
                detail="No permissions found for the user's roles.",
            )

    # Coleta os módulos associados às permissões
    if not user.is_superuser:
        modules = [permission.module for permission in permissions]

    json_data = json.dumps([asdict(module) for module in modules], default=str)
    # adiciona os módulos ao cookie
    response.set_cookie(
        key="modules",
        value=json_data,
        max_age=os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", int(3600))
    )
    response.set_cookie(
        key="usuario",
        value=user.full_name,
        max_age=os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", int(3600))
    )

    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,  # Impede o acesso via JavaScript
        # secure=True,  # Só envia o cookie por conexões seguras (HTTPS)
        samesite="strict",
        # Expira em 1 hora
        max_age=os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", int(6600)),
        expires=datetime.now(timezone.utc) + timedelta(hours=1)
    )

    # return {'access_token': access_token, 'token_type': 'Bearer'}
    # return RedirectResponse(url="/home")
    return {"message": "Login realizado com sucesso!"}


@app.get("/logout")
async def logout(
    request: Request,
    response: JSONResponse,
    user: User = Depends(get_current_user)
):
    response.set_cookie(key="modules", value='', max_age=0)

    response.set_cookie(
        key="access_token",
        value='',
        httponly=True,  # Impede o acesso via JavaScript
        secure=True,  # Só envia o cookie por conexões seguras (HTTPS)
        max_age=0,  # Expira em 1 hora
    )

    return {"message": "Logout realizado com sucesso!"}


@app.get("/home")
async def protected_page(
    request: Request
):
    logger.debug("Acessando tela home!")

    # Caso o token seja válido, renderiza a página protegida
    return templates.TemplateResponse(
        "principal.html",
        {"request": request}
    )


@app.get('/modules', response_model=ModuleList)
async def get_user_modules(
    current_user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
):

    if current_user.is_superuser:
        modules = session.scalars(
            select(Module)
        ).all()
        return {'rows': modules, 'total_records': len(modules)}

    # Obtém as roles do usuário atual
    user_roles = session.scalars(
        select(UserRoles).where(UserRoles.user_id == current_user.id)
    ).all()

    # Coleta os IDs das roles
    role_ids = [user_role.role_id for user_role in user_roles]

    if not role_ids:
        raise HTTPException(
            status_code=404, detail='No roles found for this user.'
        )

    # Obtém as permissões associadas às roles
    permissions = session.scalars(
        select(Permission).join(
            Role.permissions
        ).where(Role.id.in_(role_ids))
    ).all()

    if not permissions:
        raise HTTPException(
            status_code=404,
            detail="No permissions found for the user's roles.",
        )

    # Coleta os módulos associados às permissões
    modules = [permission.module for permission in permissions]

    return {'rows': modules, 'total_records': len(modules)}


@app.get("/editor")
async def editor(
    request: Request
):
    logger.debug("Acessando tela home!")

    # Caso o token seja válido, renderiza a página protegida
    return templates.TemplateResponse(
        "index.html",
        {"request": request}
    )

# ###################################################################
# #######
# #######================= configurações de rotas ==================#
# #######
# ###################################################################
# app.mount("/chamado", chamado_router)

app.mount("/coletiva", coletiva_router)
app.mount("/core", core_router)
app.mount("/", externo_router)

# app.include_router(core_router)

# @app.post("/upload-csv")
# @app.get("/upload-csv", response_class=HTMLResponse)
# async def upload_planilha(
# file: UploadFile = File(...), db: Session = Depends(get_db)):
#    contents = await file.read()
#    # Tenta decodificar com UTF-8 e, se falhar, usa Latin-1
#    try:
#        text = contents.decode("utf-8")
#    except UnicodeDecodeError:
#        text = contents.decode("latin1")
#
#    # Lê o CSV tratando erros e removendo espaços extras
#    df = pd.read_csv(
#        io.StringIO(text),
#        delimiter=";",
#        dtype=str,
#        engine="python",  # Trata melhor erros
#        skipinitialspace=True,  # Remove espaços antes/depois do separador
#        on_bad_lines="skip"  # Ignora linhas com erro
#    )
#
#
#    for _, row in df.iterrows():
#        cpf = row["CPF"]
#        nome = row["NOME"]
#
#        if pd.isna(cpf) or pd.isna(nome):
#            continue  # Ignorar linhas sem CPF ou Nome
#
#        cpf = cpf.strip()
#        nome = nome.strip()
#
#        # Verificar se já existe no banco
#        pessoa_existente = db.query(Pessoa).filter_by(cpf=cpf).first()
#
#        if pessoa_existente:
#            pessoa_existente.nome = nome  # Atualiza o nome se já existir
#        else:
#            nova_pessoa = Pessoa(cpf=cpf, nome=nome)
#            db.add(nova_pessoa)
#
#    db.commit()
#    return {"message": "Dados importados com sucesso!"}


if __name__ == "__main__":
    # poetry run uvicorn --host 0.0.0.0 --port 8004 app.main:app
    server = uvicorn.Server(uvicorn.Config(app, host="0.0.0.0", port=8004))
    server.run()
