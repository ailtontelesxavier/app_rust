from http import HTTPStatus

import httpx
from fastapi import HTTPException, Request

from core.settings import get_settings
from externo.schema import (
    ProcessoAssinarDocumentoSchema,
    ProcessoConsultaSchema,
    ProcessoReenviarTokenSchema,
    ProcessoValidarDocumentoSchema,
)
from util import get_numbers

from . import router

settings = get_settings()

DJANGO_API_URL = "https://api.portalacaocoletiva.com.br/api/"
CLIENT_ID = "03875564000166"
CLIENT_SECRET = "pbkdf2_sha256$260000$Q8pVTU54lK1YQGJFFOVtZP$NHjLdCSKsApgObWFm5dUMAorQ0tF2aq9CKmnMxdpzWQ="
HEADER_NAME = "header"

headers = {
    HEADER_NAME: CLIENT_SECRET
}
params = {
    "cnpj": CLIENT_ID,
}


async def get_portal_data():
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
            response = await client.get(
                DJANGO_API_URL + "portal-home",
                headers=headers,
                params=params
            )

        if response.status_code == 200:
            return response.json()

        raise HTTPException(
            status_code=response.status_code,
            detail=response.text
        )

    except Exception as e:
        print(f"Erro ao buscar portal-home: {e}")
        return {}


@router.post(
    "/processo-consulta/",
    name="processo-consulta"
)
async def processo_consulta(
    request: Request,
    form: ProcessoConsultaSchema
):
    """
    Consulta processo
    """
    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.get(
            DJANGO_API_URL + "processo-consulta",
            headers=headers,
            params={**params, 'cpf': get_numbers(form.cpf)},
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text
        )


@router.post(
    "/processo-gerar-termo/",
    name="processo-gerar-termo"
)
async def processo_gerar_termo(
    request: Request,
    form: ProcessoConsultaSchema
):
    """
    Gerar token
    """
    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.post(
            DJANGO_API_URL + "processo-gerar-termo",
            headers=headers,
            params={
                **params,
                'cpf': get_numbers(form.cpf),
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text
        )


@router.post(
    "/processo-gerar-token/",
    name="processo-gerar-token"
)
async def processo_gerar_token(
    request: Request,
    form: ProcessoReenviarTokenSchema
):
    """
    Gerar token
    """

    ambiente_producao = not settings.DEBUG

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.post(
            DJANGO_API_URL + "processo-gerar-token",
            headers=headers,
            params={
                **params,
                'cpf': get_numbers(form.cpf),
                'email': form.email,
                'celular': form.telefone,
                'ambiente_producao': ambiente_producao,
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT,
            detail=response.text
        )


@router.post(
    "/processo-assinar-documento/",
    name="processo-assinar-documento"
)
async def processo_assinar_documento(
    request: Request,
    form: ProcessoAssinarDocumentoSchema
):
    """
    assinar documento
    """

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.post(
            DJANGO_API_URL + "processo-assinar-documento",
            headers=headers,
            params={
                **params,
                'cpf': get_numbers(form.cpf),
                'token': form.token
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text
        )


@router.post(
    "/processo-validar-documento/",
    name="processo-validar-documento"
)
async def processo_validar_documento(
    request: Request,
    form: ProcessoValidarDocumentoSchema
):
    """
    assinar documento
    """

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.get(
            DJANGO_API_URL + "processo-validar-documento",
            headers=headers,
            params={
                **params,
                'codigo': form.codigo
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text
        )


@router.post(
    "/processo-reenviar-token/",
    name="processo-reenviar-token"
)
async def processo_reenviar_token(
    request: Request,
    form: ProcessoReenviarTokenSchema
):
    """
    reenviar token
    """

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        response = await client.post(
            DJANGO_API_URL + "processo-reenviar-token",
            headers=headers,
            params={
                **params,
                'cpf': get_numbers(form.cpf)
            },
        )

    if response.status_code == 200:
        return response.json()

    else:
        raise HTTPException(
            status_code=response.status_code,
            detail=response.text
        )
