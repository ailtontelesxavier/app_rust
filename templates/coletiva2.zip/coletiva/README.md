# templats
https://daisyui.com/components/button/

# Adicionar super user
$ poetry run python src/cli.py


# Execute o comando para inicializar a estrutura do Alembic
## Isso criará uma pasta alembic e um arquivo alembic.ini na raiz do seu projeto.
$ poetry run alembic init alembic

$ poetry run alembic init migrations


# Upgrade em todos os apps
$ poetry run python migrate.py all upgrade head

# Criar nova migration apenas para users
$ poetry run python migrate.py users revision --autogenerate -m "add email field"