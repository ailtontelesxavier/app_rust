"""insert initial modules

Revision ID: 30476be1bc28
Revises: 1a9dc24d2b8a
Create Date: 2025-05-01 13:52:57.818548

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '30476be1bc28'
down_revision: Union[str, None] = '1a9dc24d2b8a'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Define a tabela existente
module_table = sa.table(
    'module',
    sa.column('title', sa.String),
)

def upgrade():
    op.bulk_insert(module_table, [
        {"title": "Permissao"},
        {"title": "Users"},
        {"title": "Coletiva"},
        {"title": "Settings"},
    ])

def downgrade():
    op.execute(
        "DELETE FROM module WHERE title IN ('Permissao', 'Users', 'Coletiva', 'Settings')"
    )
