#!/bin/sh

# seta o usuário do banco de dados pois o padrão é root
export USER="app_user"
# Executa as migrações do banco de dados
# poetry run alembic upgrade head
# Inicia a aplicação
poetry run uvicorn --host 0.0.0.0 --port 8004 --workers 1 src.main:app --log-level debug
#poetry run uvicorn --host 127.0.0.1 --port 8004 --workers 1 src.main:app
#python manage.py migrate
#python run uvicorn --host 0.0.0.0 --port 8004 --workers 10 app.main:app
