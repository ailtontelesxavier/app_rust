<div align="left">

[![WateryDesert](https://img.shields.io/badge/WateryDesert-Website-F8D977?style=for-the-badge)](https://waterydesert.com)
</div>

<div align="left">
      <a href="https://youtu.be/pI2hLyHTUA4">
         <img src="https://img.youtube.com/vi/pI2hLyHTUA4/0.jpg" style="width:50%;">
      </a>
</div>

## [PlayList](https://www.youtube.com/playlist?list=PLo5Oa5DU0IYnXbSRNQrFrAW804drtEqeU)

[01 - Initial setup, routing, navigation and serving static files](https://youtu.be/LS7N9P16ppk) <br>
[Source Code](https://github.com/watery-desert/axum_askama_tutorial/tree/01)

[02 - Logging and extracting form data](https://youtu.be/IbuNH9hm7ac) <br>
[Source Code](https://github.com/watery-desert/axum_askama_tutorial/tree/02)

[03 - Form validation and setup postgreSQL database connection](https://youtu.be/I3nKm7XqZ0g) <br>
[Source Code](https://github.com/watery-desert/axum_askama_tutorial/tree/03)

[04 - Signing Up a new user and error handling](https://youtu.be/GOMoEnu-tQ0) <br>
[Source Code](https://github.com/watery-desert/axum_askama_tutorial/tree/04)

[05 - Log In using session and cookies](https://youtu.be/6Qmm6nrAWlk) <br>
[Source Code](https://github.com/watery-desert/axum_askama_tutorial/tree/05)

[06 - Log out, 404 page and flash message](https://youtu.be/BHqLC6Xaj9A) <br>
[Source Code](https://github.com/watery-desert/axum_askama_tutorial/tree/06) 

[07 - Todo CRUD, Pagination](https://youtu.be/9iWXv4XOzBI) <br>
[Source Code](https://github.com/watery-desert/axum_askama_tutorial/tree/07) 

▶ [Ip logging, CSP, Secure headers](https://youtu.be/pI2hLyHTUA4) <br>
[Source Code](https://github.com/watery-desert/axum_askama_tutorial/tree/08) 