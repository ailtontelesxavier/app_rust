
setTimeout(() => {
    const flash = document.getElementById("flash");
    if (flash) {
        flash.remove();
    }
}, 3000);